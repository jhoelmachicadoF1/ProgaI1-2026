// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 13/04/2026
// Numero de ejercicio: 4

#include <iostream>
#include <vector>
#include <string>
#include <cstdlib>
#include <ctime>
using namespace std;

void llenarPixeles(vector<int> &pixeles, int n) {
    for (int i = 0; i < n; i++) {
        pixeles.push_back(rand() % 256);
    }
}

void contarRangos(vector<int> pixeles) {
    vector<int> rangos(26, 0);

    for (int i = 0; i < pixeles.size(); i++) {
        int posicion = pixeles[i] / 10;
        rangos[posicion]++;
    }

    cout << "\nCantidad de pixeles por rangos:" << endl;

    for (int i = 0; i < rangos.size(); i++) {
        int inicio = i * 10;
        int fin = inicio + 9;

        if (fin > 255) {
            fin = 255;
        }

        cout << inicio << " - " << fin << ": " << rangos[i] << endl;
    }
}

void mostrarPixeles(vector<int> pixeles) {
    cout << "\nPixeles generados:" << endl;

    for (int i = 0; i < pixeles.size(); i++) {
        cout << pixeles[i] << " ";
    }

    cout << endl;
}

int main() {
    srand(time(0));

    vector<int> pixeles;
    int n;

    cout << "Ingrese cantidad de pixeles: ";
    cin >> n;

    llenarPixeles(pixeles, n);
    mostrarPixeles(pixeles);
    contarRangos(pixeles);

    return 0;
}
