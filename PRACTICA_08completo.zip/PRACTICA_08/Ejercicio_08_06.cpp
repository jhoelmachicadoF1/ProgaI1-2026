// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 13/04/2026
// Numero de ejercicio: 6

#include <iostream>
#include <vector>
#include <string>
using namespace std;

vector<string> separarPalabras(string oracion) {
    vector<string> palabras;
    string palabra = "";

    for (int i = 0; i < oracion.length(); i++) {
        if (oracion[i] == ' ') {
            if (palabra != "") {
                palabras.push_back(palabra);
                palabra = "";
            }
        } else {
            palabra = palabra + oracion[i];
        }
    }

    if (palabra != "") {
        palabras.push_back(palabra);
    }

    return palabras;
}

void mostrarInvertido(vector<string> palabras) {
    for (int i = palabras.size() - 1; i >= 0; i--) {
        cout << palabras[i] << " ";
    }

    cout << endl;
}

int main() {
    string oracion;
    vector<string> palabras;

    cout << "Ingrese una oracion: ";
    getline(cin, oracion);

    palabras = separarPalabras(oracion);

    cout << "Oracion invertida: ";
    mostrarInvertido(palabras);

    return 0;
}
