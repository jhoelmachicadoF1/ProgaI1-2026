// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 13/04/2026
// Numero de ejercicio: 7

#include <iostream>
#include <vector>
#include <string>
using namespace std;

bool esDigito(char caracter) {
    if (caracter >= '0' && caracter <= '9') {
        return true;
    } else {
        return false;
    }
}

string quitarDigitos(string texto) {
    string resultado = "";

    for (int i = 0; i < texto.length(); i++) {
        if (!esDigito(texto[i])) {
            resultado = resultado + texto[i];
        }
    }

    return resultado;
}

int main() {
    string texto;

    cout << "Ingrese una cadena: ";
    getline(cin, texto);

    cout << "Cadena sin digitos: " << quitarDigitos(texto) << endl;

    return 0;
}
