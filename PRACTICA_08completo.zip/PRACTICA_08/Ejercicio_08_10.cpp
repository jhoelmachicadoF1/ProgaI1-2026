// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 13/04/2026
// Numero de ejercicio: 10

#include <iostream>
#include <vector>
#include <string>
using namespace std;

char convertirMayuscula(char caracter) {
    if (caracter >= 'a' && caracter <= 'z') {
        return caracter - 32;
    } else {
        return caracter;
    }
}

string primeraLetraMayuscula(string texto) {
    bool inicioPalabra = true;

    for (int i = 0; i < texto.length(); i++) {
        if (texto[i] == ' ') {
            inicioPalabra = true;
        } else {
            if (inicioPalabra == true) {
                texto[i] = convertirMayuscula(texto[i]);
                inicioPalabra = false;
            }
        }
    }

    return texto;
}

int main() {
    string texto;

    cout << "Ingrese un texto: ";
    getline(cin, texto);

    cout << "Texto cambiado: " << primeraLetraMayuscula(texto) << endl;

    return 0;
}
