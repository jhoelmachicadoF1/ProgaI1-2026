// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 13/04/2026
// Numero de ejercicio: 5

#include <iostream>
#include <vector>
#include <string>
using namespace std;

bool validarCorreo(string correo) {
    int cantidadArroba = 0;
    int posicionArroba = -1;
    bool puntoDespues = false;

    for (int i = 0; i < correo.length(); i++) {
        if (correo[i] == '@') {
            cantidadArroba++;
            posicionArroba = i;
        }
    }

    if (cantidadArroba != 1) {
        return false;
    }

    for (int i = posicionArroba + 1; i < correo.length(); i++) {
        if (correo[i] == '.') {
            puntoDespues = true;
        }
    }

    return puntoDespues;
}

int main() {
    string correo;

    cout << "Ingrese un correo electronico: ";
    getline(cin, correo);

    if (validarCorreo(correo)) {
        cout << "Correo electronico valido" << endl;
    } else {
        cout << "Correo electronico invalido" << endl;
    }

    return 0;
}
