// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 13/04/2026
// Numero de ejercicio: 8

#include <iostream>
#include <vector>
#include <string>
using namespace std;

vector<string> separarCadena(string texto, char delimitador) {
    vector<string> partes;
    string palabra = "";

    for (int i = 0; i < texto.length(); i++) {
        if (texto[i] == delimitador) {
            partes.push_back(palabra);
            palabra = "";
        } else {
            palabra = palabra + texto[i];
        }
    }

    partes.push_back(palabra);

    return partes;
}

void mostrarPartes(vector<string> partes) {
    for (int i = 0; i < partes.size(); i++) {
        cout << partes[i] << endl;
    }
}

int main() {
    string texto;
    char delimitador;
    vector<string> partes;

    cout << "Ingrese una cadena: ";
    getline(cin, texto);

    cout << "Ingrese el delimitador: ";
    cin >> delimitador;

    partes = separarCadena(texto, delimitador);

    cout << "\nResultado:" << endl;
    mostrarPartes(partes);

    return 0;
}
