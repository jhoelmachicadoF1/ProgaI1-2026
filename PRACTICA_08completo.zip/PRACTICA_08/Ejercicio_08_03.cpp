// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 13/04/2026
// Numero de ejercicio: 3

#include <iostream>
#include <vector>
#include <string>
#include <cstdlib>
#include <ctime>
using namespace std;

void llenarCalificaciones(vector<int> &calificaciones, int n) {
    for (int i = 0; i < n; i++) {
        calificaciones.push_back(rand() % 101);
    }
}

void calcularRangos(vector<int> calificaciones) {
    int reprobado = 0;
    int regular = 0;
    int bueno = 0;
    int excelente = 0;

    for (int i = 0; i < calificaciones.size(); i++) {
        if (calificaciones[i] <= 59) {
            reprobado++;
        } else {
            if (calificaciones[i] <= 79) {
                regular++;
            } else {
                if (calificaciones[i] <= 89) {
                    bueno++;
                } else {
                    excelente++;
                }
            }
        }
    }

    double total = calificaciones.size();

    cout << "\nReprobado 0-59: " << (reprobado * 100.0) / total << "%" << endl;
    cout << "Regular 60-79: " << (regular * 100.0) / total << "%" << endl;
    cout << "Bueno 80-89: " << (bueno * 100.0) / total << "%" << endl;
    cout << "Excelente 90-100: " << (excelente * 100.0) / total << "%" << endl;
}

void mostrarCalificaciones(vector<int> calificaciones) {
    cout << "\nCalificaciones generadas:" << endl;

    for (int i = 0; i < calificaciones.size(); i++) {
        cout << calificaciones[i] << " ";
    }

    cout << endl;
}

int main() {
    srand(time(0));

    vector<int> calificaciones;
    int n;

    cout << "Ingrese cantidad de calificaciones: ";
    cin >> n;

    llenarCalificaciones(calificaciones, n);
    mostrarCalificaciones(calificaciones);
    calcularRangos(calificaciones);

    return 0;
}
