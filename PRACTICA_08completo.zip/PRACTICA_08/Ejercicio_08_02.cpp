// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 13/04/2026
// Numero de ejercicio: 2

#include <iostream>
#include <vector>
#include <string>
using namespace std;

void leerClientes(vector<string> &clientes, int n, string empresa) {
    string nombre;

    for (int i = 0; i < n; i++) {
        cout << "Ingrese cliente " << i + 1 << " de la " << empresa << ": ";
        cin >> nombre;
        clientes.push_back(nombre);
    }
}

void mostrarRepetidos(vector<string> empresa1, vector<string> empresa2) {
    int contador = 0;

    cout << "\nClientes repetidos:" << endl;

    for (int i = 0; i < empresa1.size(); i++) {
        for (int j = 0; j < empresa2.size(); j++) {
            if (empresa1[i] == empresa2[j]) {
                cout << empresa1[i] << endl;
                contador++;
            }
        }
    }

    cout << "\nCantidad de clientes en comun: " << contador << endl;
}

int main() {
    vector<string> empresa1;
    vector<string> empresa2;
    int n1, n2;

    cout << "Ingrese cantidad de clientes de la empresa 1: ";
    cin >> n1;

    leerClientes(empresa1, n1, "empresa 1");

    cout << "\nIngrese cantidad de clientes de la empresa 2: ";
    cin >> n2;

    leerClientes(empresa2, n2, "empresa 2");

    mostrarRepetidos(empresa1, empresa2);

    return 0;
}
