// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 13/04/2026
// Numero de ejercicio: 1

#include <iostream>
#include <vector>
#include <string>
#include <cstdlib>
#include <ctime>
using namespace std;

void mostrarPersona(vector<string> nombres, vector<string> apellidos, vector<int> edades) {
    int posNombre = rand() % nombres.size();
    int posApellido = rand() % apellidos.size();
    int posEdad = rand() % edades.size();

    cout << nombres[posNombre] << " " << apellidos[posApellido] << " tiene " << edades[posEdad] << " anios" << endl;
}

int main() {
    srand(time(0));

    vector<string> nombres = {"Juan", "Pedro", "Carlos", "Luis", "Marco", "Jose", "Miguel", "David", "Rene", "Jorge"};
    vector<string> apellidos = {"Perez", "Lopez", "Mamani", "Quispe", "Flores", "Vargas", "Torrez", "Rojas", "Aguilar", "Castro"};
    vector<int> edades = {18, 19, 20, 21, 22, 23, 24, 25, 26, 27};

    int n;

    cout << "Ingrese cuantas personas desea generar: ";
    cin >> n;

    for (int i = 1; i <= n; i++) {
        mostrarPersona(nombres, apellidos, edades);
    }

    return 0;
}
