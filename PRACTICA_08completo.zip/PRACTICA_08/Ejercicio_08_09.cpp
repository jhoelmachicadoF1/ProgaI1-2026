// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 13/04/2026
// Numero de ejercicio: 9

#include <iostream>
#include <vector>
#include <string>
using namespace std;

bool esLetraONumero(char caracter) {
    if (caracter >= 'A' && caracter <= 'Z') {
        return true;
    }

    if (caracter >= 'a' && caracter <= 'z') {
        return true;
    }

    if (caracter >= '0' && caracter <= '9') {
        return true;
    }

    return false;
}

char convertirMinuscula(char caracter) {
    if (caracter >= 'A' && caracter <= 'Z') {
        return caracter + 32;
    } else {
        return caracter;
    }
}

string limpiarTexto(string texto) {
    string limpio = "";

    for (int i = 0; i < texto.length(); i++) {
        if (esLetraONumero(texto[i])) {
            limpio = limpio + convertirMinuscula(texto[i]);
        }
    }

    return limpio;
}

bool esPalindromo(string texto) {
    string limpio = limpiarTexto(texto);
    int inicio = 0;
    int fin = limpio.length() - 1;

    while (inicio < fin) {
        if (limpio[inicio] != limpio[fin]) {
            return false;
        }

        inicio++;
        fin--;
    }

    return true;
}

int main() {
    string texto;

    cout << "Ingrese un texto: ";
    getline(cin, texto);

    if (esPalindromo(texto)) {
        cout << "Es palindromo" << endl;
    } else {
        cout << "No es palindromo" << endl;
    }

    return 0;
}
