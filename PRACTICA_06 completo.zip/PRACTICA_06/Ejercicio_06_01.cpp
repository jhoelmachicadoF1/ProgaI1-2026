// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 11/09/2025
// Numero de ejercicio: 1

#include <iostream>
using namespace std;

// Funcion que intercambia dos valores usando parametros por referencia
void IntercambiarValores(int &a, int &b) {
    int auxiliar = a;
    a = b;
    b = auxiliar;
}

int main() {
    int numero1, numero2;

    cout << "Ingrese el primer valor: ";
    cin >> numero1;

    cout << "Ingrese el segundo valor: ";
    cin >> numero2;

    cout << "\nValores antes de llamar a la funcion:" << endl;
    cout << "Primer valor: " << numero1 << endl;
    cout << "Segundo valor: " << numero2 << endl;

    IntercambiarValores(numero1, numero2);

    cout << "\nValores despues de llamar a la funcion:" << endl;
    cout << "Primer valor: " << numero1 << endl;
    cout << "Segundo valor: " << numero2 << endl;

    return 0;
}
