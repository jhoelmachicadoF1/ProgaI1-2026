// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 11/09/2025
// Numero de ejercicio: 4

#include <iostream>
using namespace std;

// Funcion que calcula el precio total con impuesto
// El impuesto tiene valor predeterminado de 13%
double CalcularPrecioTotal(double precioBase, double impuesto = 13) {
    double precioTotal;

    precioTotal = precioBase + (precioBase * impuesto / 100);

    return precioTotal;
}

int main() {
    double precioBase, impuesto;

    cout << "Ingrese el precio base del producto: ";
    cin >> precioBase;

    cout << "\nPrecio total con IVA boliviano del 13%: ";
    cout << CalcularPrecioTotal(precioBase) << endl;

    cout << "\nAhora ingrese otro porcentaje de impuesto: ";
    cin >> impuesto;

    cout << "Precio total con el impuesto ingresado: ";
    cout << CalcularPrecioTotal(precioBase, impuesto) << endl;

    return 0;
}
