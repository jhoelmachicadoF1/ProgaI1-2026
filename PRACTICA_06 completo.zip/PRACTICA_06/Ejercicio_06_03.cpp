// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 11/09/2025
// Numero de ejercicio: 3

#include <iostream>
using namespace std;

// La primera variable se recibe por valor y la segunda por referencia
void ModificarValores(int valor, int &referencia) {
    valor = valor * 2;
    referencia = referencia + 10;

    cout << "\nDentro de la funcion:" << endl;
    cout << "Valor pasado por valor multiplicado por 2: " << valor << endl;
    cout << "Valor pasado por referencia sumado 10: " << referencia << endl;
}

int main() {
    int numero1, numero2;

    cout << "Ingrese el primer numero: ";
    cin >> numero1;

    cout << "Ingrese el segundo numero: ";
    cin >> numero2;

    cout << "\nAntes de llamar a la funcion:" << endl;
    cout << "Primer numero: " << numero1 << endl;
    cout << "Segundo numero: " << numero2 << endl;

    ModificarValores(numero1, numero2);

    cout << "\nDespues de llamar a la funcion en el main:" << endl;
    cout << "Primer numero: " << numero1 << endl;
    cout << "Segundo numero: " << numero2 << endl;

    return 0;
}
