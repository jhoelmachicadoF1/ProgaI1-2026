// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 11/09/2025
// Numero de ejercicio: 6

#include <iostream>
using namespace std;

// Funcion que convierte segundos totales en horas, minutos y segundos
void calcularTiempo(int totalSegundos, int &horas, int &minutos, int &segundos) {
    horas = totalSegundos / 3600;
    totalSegundos = totalSegundos % 3600;

    minutos = totalSegundos / 60;
    segundos = totalSegundos % 60;
}

int main() {
    int totalSegundos;
    int horas, minutos, segundos;

    cout << "Ingrese el total de segundos: ";
    cin >> totalSegundos;

    calcularTiempo(totalSegundos, horas, minutos, segundos);

    cout << "\nTiempo calculado:" << endl;
    cout << "Horas: " << horas << endl;
    cout << "Minutos: " << minutos << endl;
    cout << "Segundos: " << segundos << endl;

    return 0;
}
