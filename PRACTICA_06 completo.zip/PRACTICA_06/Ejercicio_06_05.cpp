// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 11/09/2025
// Numero de ejercicio: 5

#include <iostream>
using namespace std;

// Funcion para calcular el area de un cuadrado
double calcularArea(double lado) {
    return lado * lado;
}

// Funcion sobrecargada para calcular el area de un rectangulo
double calcularArea(double base, double altura) {
    return base * altura;
}

// Funcion sobrecargada para calcular el area de un circulo
float calcularArea(float radio, float PI) {
    return PI * radio * radio;
}

int main() {
    double lado, base, altura;
    float radio;
    const float PI = 3.1416;

    cout << "Ingrese el lado del cuadrado: ";
    cin >> lado;

    cout << "Area del cuadrado: " << calcularArea(lado) << endl;

    cout << "\nIngrese la base del rectangulo: ";
    cin >> base;

    cout << "Ingrese la altura del rectangulo: ";
    cin >> altura;

    cout << "Area del rectangulo: " << calcularArea(base, altura) << endl;

    cout << "\nIngrese el radio del circulo: ";
    cin >> radio;

    cout << "Area del circulo: " << calcularArea(radio, PI) << endl;

    return 0;
}
