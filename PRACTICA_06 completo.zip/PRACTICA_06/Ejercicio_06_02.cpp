// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 11/09/2025
// Numero de ejercicio: 2

#include <iostream>
using namespace std;

// Funcion que calcula el volumen de un cilindro
// La altura tiene un valor por defecto de 10
double CalcularVolumen(double radio, double altura = 10) {
    const double PI = 3.1416;
    double volumen;

    volumen = PI * radio * radio * altura;

    return volumen;
}

int main() {
    double radio, altura;

    cout << "Ingrese el radio del cilindro: ";
    cin >> radio;

    cout << "Ingrese la altura del cilindro: ";
    cin >> altura;

    cout << "\nVolumen usando la altura ingresada: ";
    cout << CalcularVolumen(radio, altura) << endl;

    cout << "Volumen usando la altura por defecto de 10: ";
    cout << CalcularVolumen(radio) << endl;

    return 0;
}
