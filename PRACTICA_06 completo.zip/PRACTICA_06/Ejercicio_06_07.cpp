// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 11/09/2025
// Numero de ejercicio: 7

#include <iostream>
using namespace std;

// Funcion que agrega una nota a la suma total e incrementa el contador
void agregarNota(double &sumaTotal, int &cantidadNotas, double nuevaNota) {
    sumaTotal = sumaTotal + nuevaNota;
    cantidadNotas = cantidadNotas + 1;
}

int main() {
    int N;
    double nota;
    double sumaTotal = 0;
    int cantidadNotas = 0;

    cout << "Ingrese la cantidad de notas: ";
    cin >> N;

    for (int i = 1; i <= N; i++) {
        cout << "Ingrese la nota " << i << ": ";
        cin >> nota;

        agregarNota(sumaTotal, cantidadNotas, nota);
    }

    cout << "\nResultados:" << endl;
    cout << "Suma total de notas: " << sumaTotal << endl;
    cout << "Cantidad de notas: " << cantidadNotas << endl;

    if (cantidadNotas > 0) {
        cout << "Promedio de notas: " << sumaTotal / cantidadNotas << endl;
    } else {
        cout << "No se ingresaron notas." << endl;
    }

    return 0;
}
