// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Carnet: 7080018
// Carrera del estudiante: Ingeniería Biomédica 
// Fecha creación: 23/02/2026

#include <iostream>
using namespace std;

int main() 
{
    int n = 0;
    int total = 0;
    int pares = 0;
    int impares = 0;
    int primos = 0;
    cout << "Escribe numeros del 0 a 100 al digitar 0 termina el programa:";
    do 
    {
        cin >> n;
        if (n != 0) 
        {
            total = total + n;
            if (n % 2 == 0) 
            {
                pares = pares + n;
            } 
            else 
            {
                impares = impares + n;
            }
            int divisores = 0;
            for (int i = 1; i <= n; i++) 
            {
                if (n % i == 0) 
                {
                    divisores = divisores + 1;
                }
            }
            if (divisores == 2) 
            {
                primos = primos + n;
            }
        }
    } 
    while (n != 0);

    cout << "Suma total: " << total;
    cout << "\nSuma de pares: " << pares;
    cout << "\nSuma de impares: " << impares;
    cout << "\nSuma de primos: " << primos;

    return 0;
}