// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Carnet: 7080018
// Carrera del estudiante: Ingeniería Biomédica 
// Fecha creación: 23/02/2026

#include <iostream>
using namespace std;

int main() {
    int numero = 0;
    int suma = 0;
    cout << "digite un numero: ";
    cin >> numero;

    for (int i = 1; i < numero; i++) 
    {
        if (numero % i == 0) {
            suma = suma + i;
        }
    }
    if (suma == numero) 
    {
        cout << "Es un numero perfecto.";
    } 
    else 
    {
        cout << "No es un numero perfecto.";
    }
    return 0;
}