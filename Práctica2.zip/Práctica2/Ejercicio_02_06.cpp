// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Carnet: 7080018
// Carrera del estudiante: Ingeniería Biomédica 
// Fecha creación: 23/02/2026

#include <iostream>
using namespace std;

int main() 
{
    int numero1 = 0;
    int numero2 = 0;
    cout << "Escribe dos numeros diferentes: ";
    cin >> numero1 >> numero2;

    if (numero1 > numero2) 
    {
        for (int i = numero1; i >= numero2; i--) 
        {
            cout << i << " ";
        }
    } 
    else 
    {
        for (int i = numero1; i <= numero2; i++) 
        {
            cout << i << " ";
        }
    }
    return 0;
}