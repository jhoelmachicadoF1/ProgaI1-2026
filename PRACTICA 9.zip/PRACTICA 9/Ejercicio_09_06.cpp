// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creación: 13/04/2026
// Número de ejercicio: 6

#include <iostream>
using namespace std;

void leer(int m[10][10], int f,int c){
    for(int i=0;i<f;i++){
        for(int j=0;j<c;j++){
            cin>>m[i][j];
        }
    }
}

void transpuesta(int m[10][10], int t[10][10], int f,int c){
    for(int i=0;i<f;i++){
        for(int j=0;j<c;j++){
            t[j][i]=m[i][j];
        }
    }
}

void mostrar(int m[10][10], int f,int c){
    for(int i=0;i<f;i++){
        for(int j=0;j<c;j++){
            cout<<m[i][j]<<" ";
        }
        cout<<endl;
    }
}

int main(){
    int f,c;
    cin>>f>>c;

    int m[10][10],t[10][10];

    leer(m,f,c);
    transpuesta(m,t,f,c);

    cout<<"Original:\n";
    mostrar(m,f,c);

    cout<<"Transpuesta:\n";
    mostrar(t,c,f);
}
