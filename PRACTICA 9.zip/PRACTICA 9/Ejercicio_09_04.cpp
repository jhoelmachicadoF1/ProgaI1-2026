// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creación: 13/04/2026
// Número de ejercicio: 4

#include <iostream>
using namespace std;

void generar(int m[10][10], int n){
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            m[i][j]=2*i+j+1;
        }
    }
}

void mostrar(int m[10][10], int n){
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            cout<<m[i][j]<<" ";
        }
        cout<<endl;
    }
}

int main(){
    int n;
    cin>>n;

    int m[10][10];

    generar(m,n);
    mostrar(m,n);
}
