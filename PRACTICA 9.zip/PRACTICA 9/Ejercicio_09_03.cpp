// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creación: 13/04/2026
// Número de ejercicio: 3

#include <iostream>
#include <vector>
using namespace std;

const int F=3;
const int C=4;

void mostrar(char m[F][C]){
    for(int i=0;i<F;i++){
        for(int j=0;j<C;j++){
            cout<<m[i][j]<<" ";
        }
        cout<<endl;
    }
}

int filasSeguras(char m[F][C]){
    int cont=0;
    for(int i=0;i<F;i++){
        bool ok=true;
        for(int j=0;j<C;j++){
            if(m[i][j]=='x') ok=false;
        }
        if(ok) cont++;
    }
    return cont;
}

int columnasSeguras(char m[F][C]){
    int cont=0;
    for(int j=0;j<C;j++){
        bool ok=true;
        for(int i=0;i<F;i++){
            if(m[i][j]=='x') ok=false;
        }
        if(ok) cont++;
    }
    return cont;
}

void posiciones(char m[F][C], vector<int>& f, vector<int>& c){
    for(int i=0;i<F;i++){
        for(int j=0;j<C;j++){
            if(m[i][j]=='x'){
                f.push_back(i);
                c.push_back(j);
            }
        }
    }
}

int contar(char m[F][C]){
    int cont=0;
    for(int i=0;i<F;i++){
        for(int j=0;j<C;j++){
            if(m[i][j]=='x') cont++;
        }
    }
    return cont;
}

int main(){
    char m[F][C]={
        {'x','o','x','o'},
        {'o','o','o','o'},
        {'o','o','x','o'}
    };

    vector<int> f,c;

    mostrar(m);

    cout<<"Filas seguras: "<<filasSeguras(m)<<endl;
    cout<<"Columnas seguras: "<<columnasSeguras(m)<<endl;

    posiciones(m,f,c);

    cout<<"Posiciones x:\n";
    for(int i=0;i<f.size();i++){
        cout<<f[i]<<","<<c[i]<<endl;
    }

    cout<<"Total x: "<<contar(m)<<endl;

    int cont=0;
    for(int i=0;i<F;i++){
        if(m[i][0]=='x') cont++;
    }

    if(cont>=2)
        cout<<"No es posible entrar";
    else
        cout<<"Es posible entrar";
}
