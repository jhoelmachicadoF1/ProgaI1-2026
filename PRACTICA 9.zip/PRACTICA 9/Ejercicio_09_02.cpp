// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creación: 13/04/2026
// Número de ejercicio: 2

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cmath>
using namespace std;

void generar(int m[10][10], int n,int a,int b){
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            m[i][j]=a+rand()%(b-a+1);
        }
    }
}

int sumaCol(int m[10][10], int n){
    int s=0;
    for(int i=0;i<n;i++){
        s+=m[i][n-1];
    }
    return s;
}

int prodFila(int m[10][10], int n){
    int p=1;
    for(int j=0;j<n;j++){
        p*=m[n-1][j];
    }
    return p;
}

void mayor(int m[10][10], int n){
    int max=m[0][0],fi=0,co=0;

    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            if(m[i][j]>max){
                max=m[i][j];
                fi=i;
                co=j;
            }
        }
    }

    cout<<"Mayor: "<<max<<" Pos: "<<fi<<","<<co<<endl;
}

void desviacion(int m[10][10], int n){
    int total=n*n;
    double suma=0;

    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            suma+=m[i][j];
        }
    }

    double media=suma/total;
    double var=0;

    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            var+=pow(m[i][j]-media,2);
        }
    }

    var/=total;
    cout<<"Desviacion: "<<sqrt(var)<<endl;
}

void mostrar(int m[10][10], int n){
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            cout<<m[i][j]<<" ";
        }
        cout<<endl;
    }
}

int main(){
    srand(time(0));
    int n,a,b;
    int m[10][10];

    cin>>n>>a>>b;

    generar(m,n,a,b);
    mostrar(m,n);

    cout<<"Suma col: "<<sumaCol(m,n)<<endl;
    cout<<"Prod fila: "<<prodFila(m,n)<<endl;
    mayor(m,n);
    desviacion(m,n);
}
