// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creación: 13/04/2026

#include <iostream>
#include <vector>
#include <string>
#include <cstdlib>
#include <ctime>
using namespace std;

void mostrar(vector<string> n, vector<string> a, vector<int> e){
    int i = rand()%10;
    cout << n[i] << " " << a[i] << " - Edad: " << e[i] << endl;
}

int main(){
    srand(time(0));

    vector<string> nombres = {"jhoel","marco","kevin","elmer","jose","mateo","carla","luis","sheldon","lucas"};
    vector<string> apellidos = {"Machicado","Flores","Gomez","Rojas","Diaz","Vargas","Mamani","Quispe","sucaticona","Soto"};
    vector<int> edades = {18,20,22,19,25,30,28,21,23,24};

    int n;
    cout<<"Cuantas veces: ";
    cin>>n;

    for(int i=0;i<n;i++){
        mostrar(nombres,apellidos,edades);
    }
}