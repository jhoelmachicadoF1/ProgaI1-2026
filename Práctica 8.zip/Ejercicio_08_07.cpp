// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creación: 13/04/2026

#include <iostream>
#include <string>
using namespace std;

string limpiar(string t){
    string r="";
    for(int i=0;i<t.size();i++){
        if(!(t[i]>='0' && t[i]<='9')){
            r+=t[i];
        }
    }
    return r;
}

int main(){
    string t;
    cin>>t;
    cout<<limpiar(t);
}