// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creación: 13/04/2026

#include <iostream>
#include <string>
using namespace std;

bool validar(string c){
    int arroba=0;
    bool punto=false;

    for(int i=0;i<c.size();i++){
        if(c[i]=='@') arroba++;
        if(c[i]=='.' && arroba==1) punto=true;
    }

    return arroba==1 && punto;
}

int main(){
    string c;
    cin>>c;

    if(validar(c))
        cout<<"Valido";
    else
        cout<<"Invalido";
}