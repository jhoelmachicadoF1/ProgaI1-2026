// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creación: 13/04/2026

#include <iostream>
#include <string>
using namespace std;

string mayus(string t){
    bool inicio=true;

    for(int i=0;i<t.size();i++){
        if(inicio && t[i]!=' '){
            t[i]=toupper(t[i]);
            inicio=false;
        }
        if(t[i]==' ') inicio=true;
    }

    return t;
}

int main(){
    string t;
    getline(cin,t);
    cout<<mayus(t);
}