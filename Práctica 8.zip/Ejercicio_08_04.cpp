// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creación: 13/04/2026

#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
using namespace std;

void contar(vector<int> v){
    int rango[26]={0};

    for(int i=0;i<v.size();i++){
        rango[v[i]/10]++;
    }

    for(int i=0;i<26;i++){
        cout<<i*10<<"-"<<i*10+9<<": "<<rango[i]<<endl;
    }
}

int main(){
    srand(time(0));
    int n;
    cout<<"Cantidad: ";
    cin>>n;

    vector<int> v(n);

    for(int i=0;i<n;i++){
        v[i]=rand()%256;
    }

    contar(v);
}