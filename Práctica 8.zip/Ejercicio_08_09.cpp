// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creación: 13/04/2026

#include <iostream>
#include <string>
using namespace std;

bool pal(string t){
    string l="";

    for(int i=0;i<t.size();i++){
        if(t[i]!=' '){
            l+=tolower(t[i]);
        }
    }

    for(int i=0;i<l.size()/2;i++){
        if(l[i]!=l[l.size()-1-i]) return false;
    }

    return true;
}

int main(){
    string t;
    getline(cin,t);

    if(pal(t))
        cout<<"Palindromo";
    else
        cout<<"No es";
}