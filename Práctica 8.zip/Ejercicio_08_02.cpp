// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creación: 13/04/2026

#include <iostream>
#include <vector>
#include <string>
using namespace std;

void repetidos(vector<string> a, vector<string> b){
    for(int i=0;i<a.size();i++){
        for(int j=0;j<b.size();j++){
            if(a[i]==b[j]){
                cout<<a[i]<<endl;
            }
        }
    }
}

int main(){
    vector<string> v1={"Jhoel","Marco","Luis","Carlos"};
    vector<string> v2={"Kevin","Oscar","Ana","Mario"};

    repetidos(v1,v2);
}