// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creación: 13/04/2026

#include <iostream>
#include <string>
using namespace std;

void separar(string t,char d){
    string p="";

    for(int i=0;i<t.size();i++){
        if(t[i]==d){
            cout<<p<<endl;
            p="";
        }else{
            p+=t[i];
        }
    }
    cout<<p;
}

int main(){
    string t="Esto,es,una,cadena,separada";
    separar(t,',');
}