// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creación: 13/04/2026

#include <iostream>
#include <string>
using namespace std;

void invertir(string f){
    string palabra="",res="";

    for(int i=0;i<=f.size();i++){
        if(f[i]==' ' || i==f.size()){
            res=palabra+" "+res;
            palabra="";
        }else{
            palabra+=f[i];
        }
    }

    cout<<res;
}

int main(){
    string f;
    getline(cin,f);
    invertir(f);
}