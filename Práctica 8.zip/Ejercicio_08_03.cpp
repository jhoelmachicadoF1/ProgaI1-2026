// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creación: 13/04/2026

#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
using namespace std;

void calcular(vector<int> v)
{
    int reprobado=0;
    int regular=0;
    int bueno=0;
    int excelente=0;

    for(int i=0;i<v.size();i++)
    {
        if(v[i]<60) reprobado++;
        else if(v[i]<80) regular++;
        else if(v[i]<90) bueno++;
        else excelente++;
    }

    int n=v.size();
    cout<<"Reprobado: "<<(reprobado*100)/n<<"%"<<endl;
    cout<<"Regular: "<<(regular*100)/n<<"%"<<endl;
    cout<<"Bueno: "<<(bueno*100)/n<<"%"<<endl;
    cout<<"Excelente: "<<(excelente*100)/n<<"%"<<endl;
}

int main(){
    srand(time(0));
    int n;
    cout<<"Cantidad: ";
    cin>>n;

    vector<int> v(n);

    for(int i=0;i<n;i++){
        v[i]=rand()%101;
    }

    calcular(v);
}