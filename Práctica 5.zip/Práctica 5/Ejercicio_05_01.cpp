// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Carnet: 7080018
// Carrera: Ingeniería Biomédica
// Fecha creación: 06/03/2026

#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;
double Precio() 
{
    return 20 + rand() % (51 - 20);
}
double Descuento(double total) 
{
    if (total > 2500) 
    {
        return total * 0.95;
    }
    return total;
}

int main() 
{
    srand(time(0)); 
    int n;
    double suma = 0;

    cout << "Cuantos productos se vendieron: ";
    cin >> n;
    for(int i = 1; i <= n; i++) 
    {
        suma += Precio();
    }
    suma = Descuento(suma);
    double iva = suma * 0.13;
    cout << "\nSuma total con descuentos: " << suma << " Bs.";
    cout << "\nIVA (13%): " << iva << " Bs.";

    return 0;
}