// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores 
// Carnet: 7080018
// Carrera del estudiante: Ingenieria Biomédica 
// Fecha creación: 11/02/2026

#include <iostream>

using namespace std;

int main() 
{
    int precio_normal = 0;
    int precio_impuesto = 0;

    cout << "Costo del producto: ";
    cin >> precio_normal;

    precio_impuesto = precio_normal + (precio_normal * 0.13);

    cout << "El precio total: " << precio_impuesto;

    return 0;
}