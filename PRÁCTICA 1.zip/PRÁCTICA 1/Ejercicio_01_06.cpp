// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores 
// Carnet: 7080018
// Carrera del estudiante: Ingenieria Biomédica 
// Fecha creación: 11/02/2026

#include <iostream>

using namespace std;

int main()
 {
    int numero_entero = 0;

    cout << "Escribe un numero: ";
    cin >> numero_entero;

    if (numero_entero % 2 == 0) {
        cout << "Es numero par";
    } else {
        cout << "Es numero impar";
    }

    return 0;
}