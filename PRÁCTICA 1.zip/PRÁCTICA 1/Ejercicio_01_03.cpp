// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores 
// Carnet: 7080018
// Carrera del estudiante: Ingenieria Biomédica 
// Fecha creación: 11/02/2026
#include <iostream>

using namespace std;

int main() 
{
    int edad_persona;
    char sexo_persona;
    float altura_en_metros;

    cout << "Escribe edad:";
    cin >> edad_persona;
    cout << "Escribe sexo (M o F):";
    cin >> sexo_persona;
    cout << "Escribe tu altura: ";
    cin >> altura_en_metros;

    cout << "\n Edad: " << edad_persona;
    cout << "\n Sexo: " << sexo_persona;
    cout << "\n Altura: " << altura_en_metros;

    return 0;
}