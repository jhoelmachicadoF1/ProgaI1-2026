// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores 
// Carnet: 7080018
// Carrera del estudiante: Ingenieria Biomédica 
// Fecha creación: 11/02/2026

#include <iostream>

using namespace std;

int main() 
{
    int numero1 = 0;
    int numero2 = 0;
    int suma = 0;
    int resta = 0;
    int multiplicacion = 0;
    int division = 0;

    cout << "Escribe  primer numero: ";
    cin >> numero1;
    cout << "Escribe segundo numero: ";
    cin >> numero2;

    suma = numero1 + numero2;
    resta = numero1 - numero2;
    multiplicacion = numero1 * numero2;
    division = numero1 / numero2;

    cout << "\n La suma es: " << suma  ;
    cout << "\n La resta es: " << resta  ;
    cout << "\n La multiplicacion es: " <<  multiplicacion ;
    cout << "\n La division es: " <<  division ;

    return 0;
}