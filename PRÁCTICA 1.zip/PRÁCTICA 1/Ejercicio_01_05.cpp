// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores 
// Carnet: 7080018
// Carrera del estudiante: Ingenieria Biomédica 
// Fecha creación: 11/02/2026
#include <iostream>

using namespace std;

int main() 
{
    float cateto_a;
    float cateto_o;
    float hipotenusa_cuadrado;

    cout << "Escribe cateto adyacente: ";
    cin >> cateto_a;
    cout << "Escribe cateto opuesto: ";
    cin >> cateto_o;
    hipotenusa_cuadrado = (cateto_a * cateto_a) + (cateto_o * cateto_o);

    cout << "El resultado de la hipotenusa al cuadrado : " << hipotenusa_cuadrado;

    return 0;
}