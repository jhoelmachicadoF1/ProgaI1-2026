// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores 
// Carnet: 7080018
// Carrera del estudiante: Ingenieria Biomédica 
// Fecha creación: 11/02/2026
#include <iostream>

using namespace std;

int main() 
{
    int nota_practicas = 0;
    int nota_teoria = 0;
    int nota_participacion = 0;
    int nota_final = 0;

    cout << "Nota de practicas: ";
    cin >> nota_practicas;
    cout << "Nota de teoria: ";
    cin >> nota_teoria;
    cout << "Nota de participacion: ";
    cin >> nota_participacion;

    nota_final = (nota_practicas * 0.30) + (nota_teoria * 0.60) + (nota_participacion * 0.10);

    cout << "Tu nota final es: " << nota_final;

    return 0;
}