// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores 
// Carnet: 7080018
// Carrera del estudiante: Ingenieria Biomédica 
// Fecha creación: 11/02/2026

#include <iostream>

using namespace std;

int main() 
{
    int edad = 0;

    cout << "Escribe edad: ";
    cin >> edad;

    if (edad >= 18 && edad <= 25) 
    {
        cout << "La edad está entre el rango 18 y 25";
    } 
    else 
    {
        cout << "La edad no esta en el rango";
    }

    return 0;
}