// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores 
// Carnet: 7080018
// Carrera del estudiante: Ingenieria Biomédica 
// Fecha creación: 11/02/2026
#include <iostream>

using namespace std;

int main() 
{
    int numero1 = 0;
    int numero2 = 0;
    int numero3 = 0;
    int numero4 = 0;

    cout << "Escribe tres numeros seguidos: ";
    cin >> numero1 >> numero2 >> numero3;
    cout << "Escribe un cuarto numero: ";
    cin >> numero4;

    if (numero4 == numero1 || numero4 == numero2 || numero4 == numero3) 
    {
        cout << "Si coincide";
    }
     else
    {
        cout << "No coincide";
    }

    return 0;
}