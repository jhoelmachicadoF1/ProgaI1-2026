// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores 
// Carnet: 7080018
// Carrera del estudiante: Ingenieria Biomédica 
// Fecha creación: 11/02/2026
#include <iostream>

using namespace std;

int main() {
    int mes;

    cout << "Escribe un numero del 1 al 12: ";
    cin >> mes;

    if (mes == 1) cout << "Enero" ;
    if (mes == 2) cout << "Febrero";
    if (mes == 3) cout << "Marzo";
    if (mes == 4) cout << "Abril";
    if (mes == 5) cout << "Mayo";
    if (mes == 6) cout << "Junio";
    if (mes == 7) cout << "Julio";
    if (mes == 8) cout << "Agosto";
    if (mes == 9) cout << "Septiembre";
    if (mes == 10) cout << "Octubre";
    if (mes == 11) cout << "Noviembre";
    if (mes == 12) cout << "Diciembre";

    return 0;
}