// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores 
// Carnet: 7080018
// Carrera del estudiante: Ingenieria Biomédica 
// Fecha creación: 11/02/2026
#include <iostream>

using namespace std;

int main() 
{
    int numero;
    cout << "Numero a convertir: ";
    cin >> numero;

    cout << "En romano es: ";

    // Solo IFs simples para millares, centenas, decenas y unidades
    if (numero / 1000 == 1) cout << "M";
    if (numero / 1000 == 2) cout << "MM";
    if (numero/ 1000 == 3) cout << "MMM";

    

    return 0;
}