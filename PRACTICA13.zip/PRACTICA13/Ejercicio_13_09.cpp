// Materia: Programación I, Paralelo 4
// Grupo: 3.
// Autor: Jhel Marco Machicado Flores.
// Fecha creación: 22/05/2026

#include <iostream>
#include <string>

using namespace std;

struct Alumno
{
    string nombre;
    double t1;
    double t2;
    double t3;
    double t4;
    double ef;
    double np;
    double nf;
};

double calcularNP(double t1, double t2, double t3, double t4)
{
    double np;
    np = (t1 + t2 + t3 + t4) / 4;
    return np;
}

double calcularNF(double np, double ef)
{
    double nf;
    nf = 0.7 * np + 0.3 * ef;
    return nf;
}

void ingresarAlumnos(Alumno alumnos[], int n)
{
    for (int i = 0; i < n; i++)
    {
        cout << endl;
        cout << "ALUMNO " << i + 1 << endl;

        cin.ignore();
        cout << "Ingrese el nombre: ";
        getline(cin, alumnos[i].nombre);

        cout << "Ingrese la nota T1: ";
        cin >> alumnos[i].t1;

        cout << "Ingrese la nota T2: ";
        cin >> alumnos[i].t2;

        cout << "Ingrese la nota T3: ";
        cin >> alumnos[i].t3;

        cout << "Ingrese la nota T4: ";
        cin >> alumnos[i].t4;

        cout << "Ingrese la nota EF: ";
        cin >> alumnos[i].ef;

        alumnos[i].np = calcularNP(alumnos[i].t1, alumnos[i].t2, alumnos[i].t3, alumnos[i].t4);
        alumnos[i].nf = calcularNF(alumnos[i].np, alumnos[i].ef);
    }
}

void mostrarNotas(Alumno alumnos[], int n)
{
    cout << endl;
    cout << "NOTAS FINALES" << endl;

    for (int i = 0; i < n; i++)
    {
        cout << endl;
        cout << "Nombre: " << alumnos[i].nombre << endl;
        cout << "NP: " << alumnos[i].np << endl;
        cout << "EF: " << alumnos[i].ef << endl;
        cout << "NF: " << alumnos[i].nf << endl;
    }
}

double calcularPromedio(Alumno alumnos[], int n)
{
    double suma = 0;
    double promedio;

    for (int i = 0; i < n; i++)
    {
        suma = suma + alumnos[i].nf;
    }

    promedio = suma / n;
    return promedio;
}

double buscarMaximo(Alumno alumnos[], int n)
{
    double maximo = alumnos[0].nf;

    for (int i = 1; i < n; i++)
    {
        if (alumnos[i].nf > maximo)
        {
            maximo = alumnos[i].nf;
        }
    }

    return maximo;
}

double buscarMinimo(Alumno alumnos[], int n)
{
    double minimo = alumnos[0].nf;

    for (int i = 1; i < n; i++)
    {
        if (alumnos[i].nf < minimo)
        {
            minimo = alumnos[i].nf;
        }
    }

    return minimo;
}

int main()
{
    Alumno alumnos[100];
    int n;
    double promedio;
    double maximo;
    double minimo;

    cout << "CALIFICACIONES DEL CURSO" << endl;
    cout << "Cuantos alumnos desea registrar?: ";
    cin >> n;

    ingresarAlumnos(alumnos, n);
    mostrarNotas(alumnos, n);

    promedio = calcularPromedio(alumnos, n);
    maximo = buscarMaximo(alumnos, n);
    minimo = buscarMinimo(alumnos, n);

    cout << endl;
    cout << "Promedio de notas finales: " << promedio << endl;
    cout << "Nota final maxima: " << maximo << endl;
    cout << "Nota final minima: " << minimo << endl;

    return 0;
}
