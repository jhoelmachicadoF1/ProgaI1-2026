// Materia: Programación I, Paralelo 4
// Grupo: 3.
// Autor: Jhel Marco Machicado Flores.
// Fecha creación: 22/05/2026

#include <iostream>
#include <string>

using namespace std;

struct Alumno
{
    int cedula;
    string nombre;
    string apellido;
    int edad;
    string profesion;
    string lugar_nacimiento;
    string direccion;
    int telefono;
};

void ingresarAlumnos(Alumno alumnos[], int n)
{
    for (int i = 0; i < n; i++)
    {
        cout << endl;
        cout << "ALUMNO " << i + 1 << endl;

        cout << "Ingrese la cedula: ";
        cin >> alumnos[i].cedula;

        cin.ignore();
        cout << "Ingrese el nombre: ";
        getline(cin, alumnos[i].nombre);

        cout << "Ingrese el apellido: ";
        getline(cin, alumnos[i].apellido);

        cout << "Ingrese la edad: ";
        cin >> alumnos[i].edad;

        cin.ignore();
        cout << "Ingrese la profesion: ";
        getline(cin, alumnos[i].profesion);

        cout << "Ingrese el lugar de nacimiento: ";
        getline(cin, alumnos[i].lugar_nacimiento);

        cout << "Ingrese la direccion: ";
        getline(cin, alumnos[i].direccion);

        cout << "Ingrese el telefono: ";
        cin >> alumnos[i].telefono;
    }
}

void mostrarAlumnos(Alumno alumnos[], int n)
{
    cout << endl;
    cout << "LISTA DE ALUMNOS" << endl;

    for (int i = 0; i < n; i++)
    {
        cout << endl;
        cout << "Alumno " << i + 1 << endl;
        cout << "Cedula: " << alumnos[i].cedula << endl;
        cout << "Nombre: " << alumnos[i].nombre << endl;
        cout << "Apellido: " << alumnos[i].apellido << endl;
        cout << "Edad: " << alumnos[i].edad << endl;
        cout << "Profesion: " << alumnos[i].profesion << endl;
        cout << "Lugar de nacimiento: " << alumnos[i].lugar_nacimiento << endl;
        cout << "Direccion: " << alumnos[i].direccion << endl;
        cout << "Telefono: " << alumnos[i].telefono << endl;
    }
}

int main()
{
    Alumno alumnos[100];
    int n;

    cout << "ESTUDIANTES DE PROGRAMACION I" << endl;
    cout << "Cuantos alumnos desea registrar?: ";
    cin >> n;

    ingresarAlumnos(alumnos, n);
    mostrarAlumnos(alumnos, n);

    return 0;
}
