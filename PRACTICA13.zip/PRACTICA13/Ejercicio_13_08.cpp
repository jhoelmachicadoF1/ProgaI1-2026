// Materia: Programación I, Paralelo 4
// Grupo: 3.
// Autor: Jhel Marco Machicado Flores.
// Fecha creación: 22/05/2026

#include <iostream>
#include <string>

using namespace std;

struct AtletaOlimpiada
{
    string nombre;
    string departamento;
    string deporte;
    int medallas;
};

string elegirDepartamento(int opcion)
{
    if (opcion == 1) return "La Paz";
    if (opcion == 2) return "Cochabamba";
    if (opcion == 3) return "Santa Cruz";
    if (opcion == 4) return "Oruro";
    if (opcion == 5) return "Potosi";
    if (opcion == 6) return "Chuquisaca";
    if (opcion == 7) return "Tarija";
    if (opcion == 8) return "Beni";
    if (opcion == 9) return "Pando";

    return "No definido";
}

string elegirDeporte(int opcion)
{
    if (opcion == 1) return "Tiro con arco";
    if (opcion == 2) return "Atletismo";
    if (opcion == 3) return "Boxeo";
    if (opcion == 4) return "Ciclismo";
    if (opcion == 5) return "Natacion";
    if (opcion == 6) return "Esgrima";

    return "No definido";
}

void mostrarMenuDepartamentos()
{
    cout << "1. La Paz" << endl;
    cout << "2. Cochabamba" << endl;
    cout << "3. Santa Cruz" << endl;
    cout << "4. Oruro" << endl;
    cout << "5. Potosi" << endl;
    cout << "6. Chuquisaca" << endl;
    cout << "7. Tarija" << endl;
    cout << "8. Beni" << endl;
    cout << "9. Pando" << endl;
}

void mostrarMenuDeportes()
{
    cout << "1. Tiro con arco" << endl;
    cout << "2. Atletismo" << endl;
    cout << "3. Boxeo" << endl;
    cout << "4. Ciclismo" << endl;
    cout << "5. Natacion" << endl;
    cout << "6. Esgrima" << endl;
}

void registrarAtletas(AtletaOlimpiada atletas[], int n)
{
    int opcionDepartamento;
    int opcionDeporte;

    for (int i = 0; i < n; i++)
    {
        cout << endl;
        cout << "ATLETA " << i + 1 << endl;

        cin.ignore();
        cout << "Ingrese el nombre del atleta: ";
        getline(cin, atletas[i].nombre);

        cout << "Elija el departamento:" << endl;
        mostrarMenuDepartamentos();
        cout << "Opcion: ";
        cin >> opcionDepartamento;
        atletas[i].departamento = elegirDepartamento(opcionDepartamento);

        cout << "Elija el deporte:" << endl;
        mostrarMenuDeportes();
        cout << "Opcion: ";
        cin >> opcionDeporte;
        atletas[i].deporte = elegirDeporte(opcionDeporte);

        cout << "Ingrese cuantas medallas gano: ";
        cin >> atletas[i].medallas;
    }
}

void mostrarAtletas(AtletaOlimpiada atletas[], int n)
{
    cout << endl;
    cout << "LISTA DE ATLETAS" << endl;

    for (int i = 0; i < n; i++)
    {
        cout << endl;
        cout << "Nombre: " << atletas[i].nombre << endl;
        cout << "Departamento: " << atletas[i].departamento << endl;
        cout << "Deporte: " << atletas[i].deporte << endl;
        cout << "Medallas: " << atletas[i].medallas << endl;
    }
}

void mostrarMedallero(AtletaOlimpiada atletas[], int n)
{
    string departamentos[9] = {"La Paz", "Cochabamba", "Santa Cruz", "Oruro", "Potosi", "Chuquisaca", "Tarija", "Beni", "Pando"};
    int medallas[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < 9; j++)
        {
            if (atletas[i].departamento == departamentos[j])
            {
                medallas[j] = medallas[j] + atletas[i].medallas;
            }
        }
    }

    cout << endl;
    cout << "MEDALLERO FINAL POR DEPARTAMENTO" << endl;

    for (int i = 0; i < 9; i++)
    {
        cout << departamentos[i] << ": " << medallas[i] << " medallas" << endl;
    }
}

int main()
{
    AtletaOlimpiada atletas[100];
    int n;

    cout << "OLIMPIADA NACIONAL" << endl;
    cout << "Cuantos atletas desea registrar?: ";
    cin >> n;

    registrarAtletas(atletas, n);
    mostrarAtletas(atletas, n);
    mostrarMedallero(atletas, n);

    return 0;
}
