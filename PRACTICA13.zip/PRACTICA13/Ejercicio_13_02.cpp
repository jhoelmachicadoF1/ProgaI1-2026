// Materia: Programación I, Paralelo 4
// Grupo: 3.
// Autor: Jhel Marco Machicado Flores.
// Fecha creación: 22/05/2026

#include <iostream>
#include <string>

using namespace std;

struct Atleta
{
    string nombre;
    string pais;
    int edad;
    int mejor_tiempo;
};

void ingresarAtletas(Atleta atletas[], int n)
{
    for (int i = 0; i < n; i++)
    {
        cout << endl;
        cout << "ATLETA " << i + 1 << endl;

        cin.ignore();
        cout << "Ingrese el nombre: ";
        getline(cin, atletas[i].nombre);

        cout << "Ingrese el pais: ";
        getline(cin, atletas[i].pais);

        cout << "Ingrese la edad: ";
        cin >> atletas[i].edad;

        cout << "Ingrese el mejor tiempo en segundos: ";
        cin >> atletas[i].mejor_tiempo;
    }
}

int buscarMejorAtleta(Atleta atletas[], int n)
{
    int posicion = 0;

    for (int i = 1; i < n; i++)
    {
        if (atletas[i].mejor_tiempo < atletas[posicion].mejor_tiempo)
        {
            posicion = i;
        }
    }

    return posicion;
}

void mostrarMejorAtleta(Atleta atletas[], int posicion)
{
    cout << endl;
    cout << "ATLETA CON MEJOR TIEMPO" << endl;
    cout << "Nombre: " << atletas[posicion].nombre << endl;
    cout << "Pais: " << atletas[posicion].pais << endl;
    cout << "Mejor tiempo: " << atletas[posicion].mejor_tiempo << " segundos" << endl;
}

int main()
{
    Atleta atletas[100];
    int n;
    int posicion;

    cout << "DATOS DE ATLETAS" << endl;
    cout << "Cuantos atletas desea registrar?: ";
    cin >> n;

    ingresarAtletas(atletas, n);
    posicion = buscarMejorAtleta(atletas, n);
    mostrarMejorAtleta(atletas, posicion);

    return 0;
}
