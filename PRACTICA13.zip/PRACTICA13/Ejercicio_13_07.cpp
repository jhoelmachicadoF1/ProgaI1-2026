// Materia: Programación I, Paralelo 4
// Grupo: 3.
// Autor: Jhel Marco Machicado Flores.
// Fecha creación: 22/05/2026

#include <iostream>
#include <string>

using namespace std;

struct Producto
{
    string nombre;
    string codigo;
    double precio;
    int cantidad_en_inventario;
    string observaciones;
};

void revisarCantidad(Producto &producto)
{
    if (producto.cantidad_en_inventario < 5)
    {
        producto.observaciones = "PRODUCTO CON BAJA CANTIDAD DE INVENTARIO";
    }
    else
    {
        producto.observaciones = "Cantidad suficiente";
    }
}

void registrarProductos(Producto productos[], int n)
{
    for (int i = 0; i < n; i++)
    {
        cout << endl;
        cout << "PRODUCTO " << i + 1 << endl;

        cin.ignore();
        cout << "Ingrese el nombre: ";
        getline(cin, productos[i].nombre);

        cout << "Ingrese el codigo: ";
        getline(cin, productos[i].codigo);

        cout << "Ingrese el precio: ";
        cin >> productos[i].precio;

        cout << "Ingrese la cantidad en inventario: ";
        cin >> productos[i].cantidad_en_inventario;

        revisarCantidad(productos[i]);
    }
}

int buscarProductoMasCaro(Producto productos[], int n)
{
    int posicion = 0;

    for (int i = 1; i < n; i++)
    {
        if (productos[i].precio > productos[posicion].precio)
        {
            posicion = i;
        }
    }

    return posicion;
}

int calcularTotalInventario(Producto productos[], int n)
{
    int total = 0;

    for (int i = 0; i < n; i++)
    {
        total = total + productos[i].cantidad_en_inventario;
    }

    return total;
}

void mostrarProducto(Producto producto)
{
    cout << "Nombre: " << producto.nombre << endl;
    cout << "Codigo: " << producto.codigo << endl;
    cout << "Precio: " << producto.precio << endl;
    cout << "Cantidad en inventario: " << producto.cantidad_en_inventario << endl;
    cout << "Observaciones: " << producto.observaciones << endl;
}

int main()
{
    Producto productos[100];
    int n;
    int posicionCaro;
    int totalInventario;

    cout << "INVENTARIO DE PRODUCTOS" << endl;
    cout << "Cuantos productos desea registrar?: ";
    cin >> n;

    registrarProductos(productos, n);

    posicionCaro = buscarProductoMasCaro(productos, n);
    totalInventario = calcularTotalInventario(productos, n);

    cout << endl;
    cout << "PRODUCTO MAS CARO" << endl;
    mostrarProducto(productos[posicionCaro]);

    cout << endl;
    cout << "Cantidad total de productos en inventario: " << totalInventario << endl;

    return 0;
}
