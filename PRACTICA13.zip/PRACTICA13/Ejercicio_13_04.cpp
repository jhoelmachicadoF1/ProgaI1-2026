// Materia: Programación I, Paralelo 4
// Grupo: 3.
// Autor: Jhel Marco Machicado Flores.
// Fecha creación: 22/05/2026

#include <iostream>
#include <string>

using namespace std;

struct Empleado
{
    string nombre;
    string genero;
    double salario;
};

void ingresarEmpleados(Empleado empleados[], int n)
{
    for (int i = 0; i < n; i++)
    {
        cout << endl;
        cout << "EMPLEADO " << i + 1 << endl;

        cin.ignore();
        cout << "Ingrese el nombre: ";
        getline(cin, empleados[i].nombre);

        cout << "Ingrese el genero: ";
        getline(cin, empleados[i].genero);

        cout << "Ingrese el salario: ";
        cin >> empleados[i].salario;
    }
}

int buscarMayorSalario(Empleado empleados[], int n)
{
    int posicion = 0;

    for (int i = 1; i < n; i++)
    {
        if (empleados[i].salario > empleados[posicion].salario)
        {
            posicion = i;
        }
    }

    return posicion;
}

int buscarMenorSalario(Empleado empleados[], int n)
{
    int posicion = 0;

    for (int i = 1; i < n; i++)
    {
        if (empleados[i].salario < empleados[posicion].salario)
        {
            posicion = i;
        }
    }

    return posicion;
}

void mostrarEmpleado(Empleado empleado)
{
    cout << "Nombre: " << empleado.nombre << endl;
    cout << "Genero: " << empleado.genero << endl;
    cout << "Salario: " << empleado.salario << endl;
}

int main()
{
    Empleado empleados[100];
    int n;
    int mayor;
    int menor;

    cout << "PERSONAL DE LA UCB" << endl;
    cout << "Cuantos empleados desea registrar?: ";
    cin >> n;

    ingresarEmpleados(empleados, n);

    mayor = buscarMayorSalario(empleados, n);
    menor = buscarMenorSalario(empleados, n);

    cout << endl;
    cout << "EMPLEADO CON MAYOR SALARIO" << endl;
    mostrarEmpleado(empleados[mayor]);

    cout << endl;
    cout << "EMPLEADO CON MENOR SALARIO" << endl;
    mostrarEmpleado(empleados[menor]);

    return 0;
}
