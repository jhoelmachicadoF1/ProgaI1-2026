// Materia: Programación I, Paralelo 4
// Grupo: 3.
// Autor: Jhel Marco Machicado Flores.
// Fecha creación: 22/05/2026

#include <iostream>
#include <string>

using namespace std;

struct Libro
{
    string titulo;
    string autor;
    int anio_publicacion;
    bool disponible;
};

void registrarLibro(Libro &libro)
{
    int opcion;

    cout << "REGISTRO DE BIBLIOTECA" << endl;

    cout << "Ingrese el titulo del libro: ";
    getline(cin, libro.titulo);

    cout << "Ingrese el autor del libro: ";
    getline(cin, libro.autor);

    cout << "Ingrese el anio de publicacion: ";
    cin >> libro.anio_publicacion;

    cout << "El libro esta disponible? (1 = Si, 0 = No): ";
    cin >> opcion;

    if (opcion == 1)
    {
        libro.disponible = true;
    }
    else
    {
        libro.disponible = false;
    }
}

void mostrarLibro(Libro libro)
{
    cout << endl;
    cout << "DATOS DEL LIBRO" << endl;
    cout << "Titulo: " << libro.titulo << endl;
    cout << "Autor: " << libro.autor << endl;
    cout << "Anio de publicacion: " << libro.anio_publicacion << endl;

    if (libro.disponible == true)
    {
        cout << "Estado: Disponible" << endl;
    }
    else
    {
        cout << "Estado: No disponible" << endl;
    }
}

int main()
{
    Libro libro;

    registrarLibro(libro);
    mostrarLibro(libro);

    return 0;
}
