// Materia: Programación I, Paralelo 4
// Grupo: 3.
// Autor: Jhel Marco Machicado Flores.
// Fecha creación: 22/05/2026

#include <iostream>
#include <string>

using namespace std;

struct Empleado
{
    string nombre;
    int id;
    double sueldo;
    int antiguedad;
};

void ingresarEmpleados(Empleado empleados[], int n)
{
    for (int i = 0; i < n; i++)
    {
        cout << endl;
        cout << "EMPLEADO " << i + 1 << endl;

        cin.ignore();
        cout << "Ingrese el nombre: ";
        getline(cin, empleados[i].nombre);

        cout << "Ingrese el ID: ";
        cin >> empleados[i].id;

        cout << "Ingrese el sueldo: ";
        cin >> empleados[i].sueldo;

        cout << "Ingrese la antiguedad en anios: ";
        cin >> empleados[i].antiguedad;
    }
}

int contarSueldosMayores(Empleado empleados[], int n, double sueldoBuscado)
{
    int contador = 0;

    for (int i = 0; i < n; i++)
    {
        if (empleados[i].sueldo > sueldoBuscado)
        {
            contador++;
        }
    }

    return contador;
}

double calcularPromedioAntiguedad(Empleado empleados[], int n)
{
    int suma = 0;
    double promedio;

    for (int i = 0; i < n; i++)
    {
        suma = suma + empleados[i].antiguedad;
    }

    promedio = (double)suma / n;

    return promedio;
}

int main()
{
    Empleado empleados[100];
    int n;
    double sueldoBuscado;
    int cantidad;
    double promedio;

    cout << "GESTION DE EMPLEADOS" << endl;
    cout << "Cuantos empleados desea registrar?: ";
    cin >> n;

    ingresarEmpleados(empleados, n);

    cout << endl;
    cout << "Ingrese un sueldo para comparar: ";
    cin >> sueldoBuscado;

    cantidad = contarSueldosMayores(empleados, n, sueldoBuscado);
    promedio = calcularPromedioAntiguedad(empleados, n);

    cout << endl;
    cout << "Cantidad de empleados con sueldo mayor a " << sueldoBuscado << ": " << cantidad << endl;
    cout << "Promedio de antiguedad: " << promedio << " anios" << endl;

    return 0;
}
