// Materia: Programación I, Paralelo 4
// Grupo: 3.
// Autor: Jhel Marco Machicado Flores.
// Fecha creación: 22/05/2026

#include <iostream>
#include <string>

using namespace std;

struct Pelicula
{
    string titulo;
    string director;
    int duracion;
    int anio_estreno;
    string genero;
};

void ingresarPeliculas(Pelicula peliculas[], int n)
{
    for (int i = 0; i < n; i++)
    {
        cout << endl;
        cout << "PELICULA " << i + 1 << endl;

        cin.ignore();
        cout << "Ingrese el titulo: ";
        getline(cin, peliculas[i].titulo);

        cout << "Ingrese el director: ";
        getline(cin, peliculas[i].director);

        cout << "Ingrese la duracion en minutos: ";
        cin >> peliculas[i].duracion;

        cout << "Ingrese el anio de estreno: ";
        cin >> peliculas[i].anio_estreno;

        cin.ignore();
        cout << "Ingrese el genero: ";
        getline(cin, peliculas[i].genero);
    }
}

void mostrarPelicula(Pelicula pelicula)
{
    cout << endl;
    cout << "Titulo: " << pelicula.titulo << endl;
    cout << "Director: " << pelicula.director << endl;
    cout << "Duracion: " << pelicula.duracion << " minutos" << endl;
    cout << "Anio de estreno: " << pelicula.anio_estreno << endl;
    cout << "Genero: " << pelicula.genero << endl;
}

void buscarPorGenero(Pelicula peliculas[], int n, string generoBuscado)
{
    bool encontrado = false;

    cout << endl;
    cout << "PELICULAS DEL GENERO: " << generoBuscado << endl;

    for (int i = 0; i < n; i++)
    {
        if (peliculas[i].genero == generoBuscado)
        {
            mostrarPelicula(peliculas[i]);
            encontrado = true;
        }
    }

    if (encontrado == false)
    {
        cout << "No se encontraron peliculas de ese genero." << endl;
    }
}

void buscarPorDirector(Pelicula peliculas[], int n, string directorBuscado)
{
    bool encontrado = false;

    cout << endl;
    cout << "PELICULAS DEL DIRECTOR: " << directorBuscado << endl;

    for (int i = 0; i < n; i++)
    {
        if (peliculas[i].director == directorBuscado)
        {
            mostrarPelicula(peliculas[i]);
            encontrado = true;
        }
    }

    if (encontrado == false)
    {
        cout << "No se encontraron peliculas de ese director." << endl;
    }
}

int main()
{
    Pelicula peliculas[100];
    int n;
    string generoBuscado;
    string directorBuscado;

    cout << "SISTEMA DE GESTION DE PELICULAS" << endl;
    cout << "Cuantas peliculas desea registrar?: ";
    cin >> n;

    ingresarPeliculas(peliculas, n);

    cin.ignore();
    cout << endl;
    cout << "Ingrese el genero que desea buscar: ";
    getline(cin, generoBuscado);

    cout << "Ingrese el director que desea buscar: ";
    getline(cin, directorBuscado);

    buscarPorGenero(peliculas, n, generoBuscado);
    buscarPorDirector(peliculas, n, directorBuscado);

    return 0;
}
