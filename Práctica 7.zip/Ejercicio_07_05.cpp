// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores (ARRNA)
// Fecha creación: 27/03/2026
// Número de ejercicio: 5

#include <iostream>
using namespace std;

void combinar(){
    int n;
    cout<<"Ingrese tamaño: ";
    cin>>n;

    if(n<=0 || n>100){
        cout<<"Error"<<endl;
        return;
    }

    int v1[100], v2[100], v3[200];

    cout<<"Ingrese vector 1:"<<endl;
    for(int i=0;i<n;i++){
        cin>>v1[i];
    }

    cout<<"Ingrese vector 2:"<<endl;
    for(int i=0;i<n;i++){
        cin>>v2[i];
    }

    for(int i=0;i<n;i++) v3[i]=v1[i];
    for(int i=0;i<n;i++) v3[i+n]=v2[i];

    cout<<"Vector combinado:"<<endl;
    for(int i=0;i<2*n;i++) cout<<v3[i]<<" ";
}

int main(){
    combinar();
    return 0;
}