// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores (ARRNA)
// Fecha creación: 27/03/2026
// Número de ejercicio: 7

#include <iostream>
using namespace std;

void llenar(){
    int v[10];
    int i=0, num;

    cout<<"Ingrese numeros (negativo para terminar):"<<endl;

    while(i<10){
        cin>>num;
        if(num<0) break;

        v[i]=num;
        i++;
    }

    cout<<"Vector:"<<endl;
    for(int j=0;j<i;j++){
        cout<<v[j]<<" ";
    }
}

int main(){
    llenar();
    return 0;
}