// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores (ARRNA)
// Fecha creación: 27/03/2026
// Número de ejercicio: 4

#include <iostream>
using namespace std;

void multiplicar(){
    int n;
    cout<<"Ingrese tamaño del vector: ";
    cin>>n;

    if(n<=0 || n>100){
        cout<<"Error"<<endl;
        return;
    }

    int v1[100], v2[100], v3[100];

    cout<<"Ingrese vector 1:"<<endl;
    for(int i=0;i<n;i++){
        cout<<"v1["<<i<<"] = ";
        cin>>v1[i];
    }

    cout<<"Ingrese vector 2:"<<endl;
    for(int i=0;i<n;i++){
        cout<<"v2["<<i<<"] = ";
        cin>>v2[i];
    }

    cout<<"Resultado:"<<endl;
    for(int i=0;i<n;i++){
        v3[i]=v1[i]*v2[i];
        cout<<v3[i]<<" ";
    }
}

int main(){
    multiplicar();
    return 0;
}