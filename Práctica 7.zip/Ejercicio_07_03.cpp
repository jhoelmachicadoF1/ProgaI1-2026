// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creación: 27/03/2026
// Número de ejercicio: 3

#include <iostream>
using namespace std;

void proceso(){
    int n;
    cout<<"Ingrese cantidad: ";
    cin>>n;

    int calificaciones[100];
    float desviacion[100];

    float suma=0, promedio;

    // ingreso
    for(int i=0;i<n;i++){
        cout<<"Ingrese nota: ";
        cin>>calificaciones[i];
        suma += calificaciones[i];
    }

    promedio = suma/n;
    cout<<"Promedio: "<<promedio<<endl;

    float varianza=0;

    for(int i=0;i<n;i++){
        desviacion[i] = calificaciones[i] - promedio;
        cout<<"Nota: "<<calificaciones[i]
            <<"  Desviacion: "<<desviacion[i]<<endl;

        varianza += desviacion[i]*desviacion[i];
    }

    varianza = varianza/n;
    cout<<"Varianza: "<<varianza<<endl;
}

int main(){
    proceso();
    return 0;
}