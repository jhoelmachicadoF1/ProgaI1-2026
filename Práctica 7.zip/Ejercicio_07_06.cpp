// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores (ARRNA)
// Fecha creación: 27/03/2026
// Número de ejercicio: 6

#include <iostream>
using namespace std;

void suma(){
    int v1[5], v2[5], v3[5];

    cout<<"Ingrese vector 1:"<<endl;
    for(int i=0;i<5;i++){
        cin>>v1[i];
    }

    cout<<"Ingrese vector 2:"<<endl;
    for(int i=0;i<5;i++){
        cin>>v2[i];
    }

    cout<<"Resultado:"<<endl;
    for(int i=0;i<5;i++){
        v3[i]=v1[i]+v2[i];
        cout<<v3[i]<<" ";
    }
}

int main(){
    suma();
    return 0;
}