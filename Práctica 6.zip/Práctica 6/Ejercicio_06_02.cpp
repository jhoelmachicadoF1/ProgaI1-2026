// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creación: 01/04/2026

#include <iostream>
using namespace std;


double CalcularVolumen(double r, double h = 10) 
{
    double pi = 3.14159;
    double res = pi * (r * r) * h;
    return res;
}

int main() 
{
    double radio;
    cout << "Pon el radio del cilindro: ";
    cin >> radio;
    
    cout << "El volumen (con altura de 10) es: " << CalcularVolumen(radio) << endl;
    
    return 0;
}