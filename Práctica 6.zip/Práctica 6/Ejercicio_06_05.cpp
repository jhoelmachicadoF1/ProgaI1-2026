// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creación: 01/04/2026

#include <iostream>
using namespace std;

double calcularArea(double lado) {
    return lado * lado;
}

double calcularArea(double b, double h) {
    return b * h;
}
float calcularArea(float r, float pi) {
    return pi * (r * r);
}

int main() 
{
    cout << "Cuadrado de lado 5: " << calcularArea(5.0) << endl;
    cout << "Rectangulo de 4x6: " << calcularArea(4.0, 6.0) << endl;
    cout << "Circulo de radio 3: " << calcularArea(3.0f, 3.1416f) << endl;
    
    return 0;
}