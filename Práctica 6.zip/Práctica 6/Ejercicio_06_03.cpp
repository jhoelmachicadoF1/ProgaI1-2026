// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creación: 01/04/2026

#include <iostream>
using namespace std;

void ModificarValores(int normal, int &referencia) 
{
    normal = normal * 2;       
    referencia = referencia + 10; 
}

int main() 
{
    int a = 10;
    int b = 10;
    
    ModificarValores(a, b);
    
    cout << "La variable 'a' sigue siendo: " << a << endl;
    cout << "La variable 'b' ahora es: " << b << endl;
    
    return 0;
}