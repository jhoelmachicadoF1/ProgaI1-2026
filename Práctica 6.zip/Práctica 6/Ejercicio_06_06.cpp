// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creación: 01/04/2026


#include <iostream>
using namespace std;

void calcularTiempo(int total, int &h, int &m, int &s) 
{
    h = total / 3600;          
    m = (total % 3600) / 60;   
    s = total % 60;            
}

int main() 
{
    int segsEntrada, hor, min, seg;
    cout << "Dime cuantos segundos son en total: ";
    cin >> segsEntrada;

    calcularTiempo(segsEntrada, hor, min, seg);

    cout << "Eso equivale a " << hor << "h:" << min << "m:" << seg << "s" << endl;
    
    return 0;
}