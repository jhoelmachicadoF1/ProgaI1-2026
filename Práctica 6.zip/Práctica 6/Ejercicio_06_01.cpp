// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creación: 01/04/2026
// Número de ejercicio: 1

#include <iostream>
using namespace std;

void IntercambiarValores(int &parametro1, int &parametro2) 
{
    int valores = parametro1; 
    parametro1 = parametro2;    
    parametro2 = valores;     
}

int main() 
{
    int x, y;
    cout << "Ingresa el primer numero: ";
    cin >> x;
    cout << "Ingresa el segundo numero: ";
    cin >> y;

    cout << "Antes: x=" << x << " y=" << y << endl;

    IntercambiarValores(x, y);

    cout << "Despues: x=" << x << " y=" << y << endl;
    
    return 0;
}