// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creación: 01/04/2026

#include <iostream>
using namespace std;

double CalcularPrecioTotal(double precio, double impuesto = 13) 
{
    double total = precio + (precio * impuesto / 100);
    return total;
}

int main() 
{
    double costo;
    cout << "Cuanto cuesta el producto: ";
    cin >> costo;

    cout << "Precio final con el 13% de impuesto: " << CalcularPrecioTotal(costo) << endl;
    
    return 0;
}