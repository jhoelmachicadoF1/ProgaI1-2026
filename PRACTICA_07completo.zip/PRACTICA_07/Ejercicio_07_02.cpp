// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 27/03/2026
// Numero de ejercicio: 2

#include <iostream>
using namespace std;

void mostrarVoltios(double voltios[], int cantidad) {
    for (int i = 0; i < cantidad; i++) {
        cout << voltios[i] << " ";

        if ((i + 1) % 3 == 0) {
            cout << endl;
        }
    }
}

int main() {
    double voltios[9] = {11.95, 16.32, 12.15, 8.22, 15.98, 26.22, 13.54, 6.45, 17.59};

    cout << "Valores del arreglo voltios:" << endl;

    mostrarVoltios(voltios, 9);

    return 0;
}
