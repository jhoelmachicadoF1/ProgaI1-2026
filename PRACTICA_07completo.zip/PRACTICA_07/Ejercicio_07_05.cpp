// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 27/03/2026
// Numero de ejercicio: 5

#include <iostream>
using namespace std;

void leerVector(int vector[], int n, string nombre) {
    for (int i = 0; i < n; i++) {
        cout << "Ingrese el valor " << i + 1 << " del " << nombre << ": ";
        cin >> vector[i];
    }
}

void combinarVectores(int vector1[], int vector2[], int combinado[], int n) {
    for (int i = 0; i < n; i++) {
        combinado[i] = vector1[i];
    }

    for (int i = 0; i < n; i++) {
        combinado[n + i] = vector2[i];
    }
}

void mostrarVector(int vector[], int n) {
    for (int i = 0; i < n; i++) {
        cout << vector[i] << " ";
    }
    cout << endl;
}

int main() {
    int n;
    int vector1[100];
    int vector2[100];
    int combinado[200];

    cout << "Ingrese la dimension de los vectores: ";
    cin >> n;

    leerVector(vector1, n, "vector 1");
    leerVector(vector2, n, "vector 2");

    combinarVectores(vector1, vector2, combinado, n);

    cout << "\nVector combinado:" << endl;
    mostrarVector(combinado, 2 * n);

    return 0;
}
