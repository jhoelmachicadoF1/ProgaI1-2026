// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 27/03/2026
// Numero de ejercicio: 6

#include <iostream>
using namespace std;

void leerVector(int vector[], string nombre) {
    for (int i = 0; i < 5; i++) {
        cout << "Ingrese el valor " << i + 1 << " de " << nombre << ": ";
        cin >> vector[i];
    }
}

void sumarVectores(int vector1[], int vector2[], int vector3[]) {
    for (int i = 0; i < 5; i++) {
        vector3[i] = vector1[i] + vector2[i];
    }
}

void mostrarVector(int vector[]) {
    for (int i = 0; i < 5; i++) {
        cout << vector[i] << " ";
    }
    cout << endl;
}

int main() {
    int vector1[5];
    int vector2[5];
    int vector3[5];

    leerVector(vector1, "vector1");
    leerVector(vector2, "vector2");

    sumarVectores(vector1, vector2, vector3);

    cout << "\nVector3 = vector1 + vector2:" << endl;
    mostrarVector(vector3);

    return 0;
}
