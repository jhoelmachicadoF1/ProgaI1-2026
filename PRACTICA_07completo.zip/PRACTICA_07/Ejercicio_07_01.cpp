// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 27/03/2026
// Numero de ejercicio: 1

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
using namespace std;

double generarDecimal(double minimo, double maximo) {
    double numero;
    numero = minimo + (rand() / (double)RAND_MAX) * (maximo - minimo);
    return numero;
}

void generarVoltajes(double voltajes[], int cantidad) {
    cout << "\nVOLTAJES" << endl;
    for (int i = 0; i < cantidad; i++) {
        voltajes[i] = generarDecimal(20.00, 220.00);
        cout << fixed << setprecision(2) << voltajes[i] << " V" << endl;
    }
}

void generarTemperaturas(double temperaturas[], int cantidad) {
    cout << "\nTEMPERATURAS" << endl;
    for (int i = 0; i < cantidad; i++) {
        temperaturas[i] = generarDecimal(0.00, 100.00);
        cout << fixed << setprecision(2) << temperaturas[i] << endl;
    }
}

void generarCaracteres(char caracteres[], int cantidad) {
    cout << "\nCARACTERES ALFANUMERICOS" << endl;
    for (int i = 0; i < cantidad; i++) {
        int opcion = rand() % 3;

        if (opcion == 0) {
            caracteres[i] = 'A' + rand() % 26;
        } else {
            if (opcion == 1) {
                caracteres[i] = 'a' + rand() % 26;
            } else {
                caracteres[i] = '0' + rand() % 10;
            }
        }

        cout << caracteres[i] << " ";
    }
    cout << endl;
}

void generarAnios(int anios[], int cantidad) {
    cout << "\nANIOS" << endl;
    for (int i = 0; i < cantidad; i++) {
        anios[i] = 1990 + rand() % 36;
        cout << anios[i] << endl;
    }
}

void generarVelocidades(double velocidades[], int cantidad) {
    cout << "\nVELOCIDADES" << endl;
    for (int i = 0; i < cantidad; i++) {
        velocidades[i] = generarDecimal(10.00, 300.00);
        cout << fixed << setprecision(2) << velocidades[i] << endl;
    }
}

void generarDistancias(double distancias[], int cantidad) {
    cout << "\nDISTANCIAS" << endl;
    for (int i = 0; i < cantidad; i++) {
        distancias[i] = generarDecimal(1.00, 1000.00);
        cout << fixed << setprecision(2) << distancias[i] << endl;
    }
}

int main() {
    srand(time(0));

    double voltajes[100];
    double temperaturas[50];
    char caracteres[30];
    int anios[100];
    double velocidades[32];
    double distancias[1000];

    generarVoltajes(voltajes, 100);
    generarTemperaturas(temperaturas, 50);
    generarCaracteres(caracteres, 30);
    generarAnios(anios, 100);
    generarVelocidades(velocidades, 32);
    generarDistancias(distancias, 1000);

    return 0;
}
