// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 27/03/2026
// Numero de ejercicio: 3

#include <iostream>
using namespace std;

void leerCalificaciones(int calificaciones[], int n) {
    for (int i = 0; i < n; i++) {
        cout << "Ingrese la calificacion " << i + 1 << ": ";
        cin >> calificaciones[i];
    }
}

double calcularSuma(int calificaciones[], int n) {
    double suma = 0;

    for (int i = 0; i < n; i++) {
        suma = suma + calificaciones[i];
    }

    return suma;
}

double calcularPromedio(double suma, int n) {
    double promedio;
    promedio = suma / n;
    return promedio;
}

void calcularDesviaciones(int calificaciones[], double desviacion[], int n, double promedio) {
    for (int i = 0; i < n; i++) {
        desviacion[i] = calificaciones[i] - promedio;
    }
}

double calcularVarianza(double desviacion[], int n) {
    double sumaDesviaciones = 0;
    double varianza;

    for (int i = 0; i < n; i++) {
        sumaDesviaciones = sumaDesviaciones + (desviacion[i] * desviacion[i]);
    }

    varianza = sumaDesviaciones / n;

    return varianza;
}

void mostrarDatos(int calificaciones[], double desviacion[], int n) {
    cout << "\nCalificacion    Desviacion" << endl;

    for (int i = 0; i < n; i++) {
        cout << calificaciones[i] << "              " << desviacion[i] << endl;
    }
}

int main() {
    int n;
    int calificaciones[100];
    double desviacion[100];
    double suma;
    double promedio;
    double varianza;

    cout << "Ingrese la cantidad de calificaciones: ";
    cin >> n;

    leerCalificaciones(calificaciones, n);

    suma = calcularSuma(calificaciones, n);
    promedio = calcularPromedio(suma, n);

    calcularDesviaciones(calificaciones, desviacion, n, promedio);

    varianza = calcularVarianza(desviacion, n);

    cout << "\nSuma total: " << suma << endl;
    cout << "Promedio: " << promedio << endl;

    mostrarDatos(calificaciones, desviacion, n);

    cout << "\nVarianza: " << varianza << endl;

    return 0;
}
