// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 27/03/2026
// Numero de ejercicio: 7

#include <iostream>
using namespace std;

int llenarVector(int vector[]) {
    int numero;
    int cantidad = 0;

    while (cantidad < 10) {
        cout << "Ingrese un numero entero: ";
        cin >> numero;

        if (numero < 0) {
            break;
        }

        vector[cantidad] = numero;
        cantidad++;
    }

    return cantidad;
}

void mostrarVector(int vector[], int cantidad) {
    cout << "\nElementos ingresados:" << endl;

    for (int i = 0; i < cantidad; i++) {
        cout << vector[i] << " ";
    }

    cout << endl;
}

int main() {
    int vector[10];
    int cantidad;

    cantidad = llenarVector(vector);

    mostrarVector(vector, cantidad);

    return 0;
}
