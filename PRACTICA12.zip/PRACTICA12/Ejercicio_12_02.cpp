// Materia: Programación I, Paralelo 4
// Grupo: 3.
// Autor: Jhel Marco Machicado Flores.
// Fecha creación: 13/05/2026
// Número de ejercicio: 2

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int contarPalabras()
{
    ifstream archivo("texto.txt");
    string palabra;
    int contador = 0;

    if (!archivo.is_open())
    {
        cout << "No se pudo abrir el archivo texto.txt" << endl;
        return 0;
    }

    while (archivo >> palabra)
    {
        contador++;
    }

    archivo.close();
    return contador;
}

int main()
{
    int total;

    total = contarPalabras();

    cout << "El archivo texto.txt tiene " << total << " palabras." << endl;

    return 0;
}
