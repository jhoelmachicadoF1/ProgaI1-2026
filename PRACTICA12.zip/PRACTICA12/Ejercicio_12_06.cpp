// Materia: Programación I, Paralelo 4
// Grupo: 3.
// Autor: Jhel Marco Machicado Flores.
// Fecha creación: 13/05/2026
// Número de ejercicio: 6

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

void filtrarTemperaturas(double limite)
{
    ifstream archivo("temperaturas.txt");
    ofstream salida("altas_temperaturas.txt");
    string ciudad;
    double temperatura;

    if (!archivo.is_open())
    {
        cout << "No se pudo abrir el archivo temperaturas.txt" << endl;
        return;
    }

    while (archivo >> ciudad >> temperatura)
    {
        if (temperatura > limite)
        {
            salida << ciudad << " " << temperatura << endl;
        }
    }

    archivo.close();
    salida.close();
}

int main()
{
    double limite;

    cout << "Ingrese la temperatura limite: ";
    cin >> limite;

    filtrarTemperaturas(limite);

    cout << "Se genero el archivo altas_temperaturas.txt" << endl;

    return 0;
}
