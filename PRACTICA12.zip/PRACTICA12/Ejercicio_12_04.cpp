// Materia: Programación I, Paralelo 4
// Grupo: 3.
// Autor: Jhel Marco Machicado Flores.
// Fecha creación: 13/05/2026
// Número de ejercicio: 4

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

string leerArchivoCompleto()
{
    ifstream archivo("datos.txt");
    string linea;
    string texto = "";

    if (!archivo.is_open())
    {
        cout << "No se pudo abrir el archivo datos.txt" << endl;
        return "";
    }

    while (getline(archivo, linea))
    {
        texto = texto + linea + "\n";
    }

    archivo.close();
    return texto;
}

int contarApariciones(string texto, string buscar)
{
    int contador = 0;
    int posicion = 0;

    while (posicion < (int)texto.length())
    {
        posicion = texto.find(buscar, posicion);

        if (posicion == -1)
        {
            break;
        }

        contador++;
        posicion = posicion + buscar.length();
    }

    return contador;
}

int main()
{
    string texto;
    string buscar;
    int veces;

    texto = leerArchivoCompleto();

    if (texto == "")
    {
        return 0;
    }

    cout << "Ingrese la palabra o frase que desea buscar: ";
    getline(cin, buscar);

    veces = contarApariciones(texto, buscar);

    cout << "La palabra o frase aparece " << veces << " veces." << endl;

    return 0;
}
