// Materia: Programación I, Paralelo 4
// Grupo: 3.
// Autor: Jhel Marco Machicado Flores.
// Fecha creación: 13/05/2026
// Número de ejercicio: 8

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

using namespace std;

void contarDatosArchivo(int &lineas, int &palabras, int &caracteres)
{
    ifstream archivo("documento.txt");
    string linea;
    string palabra;

    lineas = 0;
    palabras = 0;
    caracteres = 0;

    if (!archivo.is_open())
    {
        cout << "No se pudo abrir el archivo documento.txt" << endl;
        return;
    }

    while (getline(archivo, linea))
    {
        lineas++;
        caracteres = caracteres + linea.length();

        stringstream datos(linea);

        while (datos >> palabra)
        {
            palabras++;
        }
    }

    archivo.close();
}

int main()
{
    int lineas;
    int palabras;
    int caracteres;

    contarDatosArchivo(lineas, palabras, caracteres);

    cout << "Total de lineas: " << lineas << endl;
    cout << "Total de palabras: " << palabras << endl;
    cout << "Total de caracteres: " << caracteres << endl;

    return 0;
}
