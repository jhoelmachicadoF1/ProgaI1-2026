// Materia: Programación I, Paralelo 4
// Grupo: 3.
// Autor: Jhel Marco Machicado Flores.
// Fecha creación: 13/05/2026
// Número de ejercicio: 3

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

struct Estudiante
{
    string nombre;
    int edad;
    double promedio;
};

void registrarEstudiantes()
{
    ofstream archivo("estudiantes.txt");
    Estudiante estudiante;
    int cantidad;

    cout << "Cuantos estudiantes desea registrar: ";
    cin >> cantidad;
    cin.ignore();

    for (int i = 1; i <= cantidad; i++)
    {
        cout << endl;
        cout << "ESTUDIANTE " << i << endl;

        cout << "Nombre: ";
        getline(cin, estudiante.nombre);

        cout << "Edad: ";
        cin >> estudiante.edad;

        cout << "Promedio: ";
        cin >> estudiante.promedio;
        cin.ignore();

        archivo << "Nombre: " << estudiante.nombre << endl;
        archivo << "Edad: " << estudiante.edad << endl;
        archivo << "Promedio: " << estudiante.promedio << endl;
        archivo << endl;
    }

    archivo.close();
}

void mostrarEstudiantes()
{
    ifstream archivo("estudiantes.txt");
    string linea;

    if (!archivo.is_open())
    {
        cout << "No se pudo abrir el archivo estudiantes.txt" << endl;
        return;
    }

    cout << endl;
    cout << "DATOS DE LOS ESTUDIANTES" << endl;

    while (getline(archivo, linea))
    {
        cout << linea << endl;
    }

    archivo.close();
}

int main()
{
    registrarEstudiantes();
    mostrarEstudiantes();

    return 0;
}
