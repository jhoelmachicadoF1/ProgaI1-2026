// Materia: Programación I, Paralelo 4
// Grupo: 3.
// Autor: Jhel Marco Machicado Flores.
// Fecha creación: 13/05/2026
// Número de ejercicio: 7

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <iomanip>

using namespace std;

void calcularPromedios()
{
    ifstream archivo("calificaciones.txt");
    ofstream salida("promedios.txt");
    string linea;
    string nombre;
    double nota;

    if (!archivo.is_open())
    {
        cout << "No se pudo abrir el archivo calificaciones.txt" << endl;
        return;
    }

    while (getline(archivo, linea))
    {
        stringstream datos(linea);
        double suma = 0;
        int cantidad = 0;
        double promedio = 0;

        datos >> nombre;

        while (datos >> nota)
        {
            suma = suma + nota;
            cantidad++;
        }

        if (cantidad > 0)
        {
            promedio = suma / cantidad;
            salida << nombre << " " << fixed << setprecision(2) << promedio << endl;
        }
    }

    archivo.close();
    salida.close();
}

int main()
{
    calcularPromedios();

    cout << "Se genero el archivo promedios.txt" << endl;

    return 0;
}
