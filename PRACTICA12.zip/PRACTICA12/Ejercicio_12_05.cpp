// Materia: Programación I, Paralelo 4
// Grupo: 3.
// Autor: Jhel Marco Machicado Flores.
// Fecha creación: 13/05/2026
// Número de ejercicio: 5

#include <iostream>
#include <fstream>
#include <string>
#include <cstdio>

using namespace std;

bool actualizarProducto(string productoBuscado, double nuevoPrecio)
{
    ifstream archivo("productos.txt");
    ofstream temporal("temp.txt");
    string producto;
    double precio;
    bool encontrado = false;

    if (!archivo.is_open())
    {
        cout << "No se pudo abrir el archivo productos.txt" << endl;
        return false;
    }

    while (archivo >> producto >> precio)
    {
        if (producto == productoBuscado)
        {
            temporal << producto << " " << nuevoPrecio << endl;
            encontrado = true;
        }
        else
        {
            temporal << producto << " " << precio << endl;
        }
    }

    archivo.close();
    temporal.close();

    remove("productos.txt");
    rename("temp.txt", "productos.txt");

    return encontrado;
}

int main()
{
    string producto;
    double nuevoPrecio;
    bool resultado;

    cout << "Ingrese el nombre del producto: ";
    cin >> producto;

    cout << "Ingrese el nuevo precio: ";
    cin >> nuevoPrecio;

    resultado = actualizarProducto(producto, nuevoPrecio);

    if (resultado == true)
    {
        cout << "El precio fue actualizado correctamente." << endl;
    }
    else
    {
        cout << "El producto no existe." << endl;
    }

    return 0;
}
