// Materia: Programación I, Paralelo 4
// Grupo: 3.
// Autor: Jhel Marco Machicado Flores.
// Fecha creación: 13/05/2026
// Número de ejercicio: 1

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

void guardarNombres()
{
    ofstream archivo("nombres.txt");
    string nombre;
    int cantidad;

    cout << "Cuantos nombres desea ingresar: ";
    cin >> cantidad;
    cin.ignore();

    for (int i = 1; i <= cantidad; i++)
    {
        cout << "Ingrese el nombre " << i << ": ";
        getline(cin, nombre);
        archivo << nombre << endl;
    }

    archivo.close();
}

void mostrarNombres()
{
    ifstream archivo("nombres.txt");
    string nombre;

    if (!archivo.is_open())
    {
        cout << "No se pudo abrir el archivo nombres.txt" << endl;
        return;
    }

    cout << endl;
    cout << "NOMBRES GUARDADOS" << endl;

    while (getline(archivo, nombre))
    {
        cout << nombre << endl;
    }

    archivo.close();
}

int main()
{
    guardarNombres();
    mostrarNombres();

    return 0;
}
