// Materia: Programación I, Paralelo 4
// Grupo: 3.
// Autor: Jhel Marco Machicado Flores.
// Fecha creación: 13/05/2026
// Número de ejercicio: 9

#include <iostream>
#include <fstream>

using namespace std;

char cifrarLetra(char letra)
{
    if (letra >= 'A' && letra <= 'Z')
    {
        letra = ((letra - 'A' + 3) % 26) + 'A';
    }
    else
    {
        if (letra >= 'a' && letra <= 'z')
        {
            letra = ((letra - 'a' + 3) % 26) + 'a';
        }
    }

    return letra;
}

void cifrarArchivo()
{
    ifstream archivo("mensaje.txt");
    ofstream salida("mensaje_cifrado.txt");
    char letra;

    if (!archivo.is_open())
    {
        cout << "No se pudo abrir el archivo mensaje.txt" << endl;
        return;
    }

    while (archivo.get(letra))
    {
        salida << cifrarLetra(letra);
    }

    archivo.close();
    salida.close();
}

int main()
{
    cifrarArchivo();

    cout << "Se genero el archivo mensaje_cifrado.txt" << endl;

    return 0;
}
