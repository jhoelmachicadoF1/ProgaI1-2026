// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creación: 15/04/2026
// Número de ejercicio: 0

#include <iostream>
#include <vector>
#include <string>
#include <cstdlib>
#include <ctime>
using namespace std;

void generar(vector<string> nombres, vector<string> apellidos, int N){
    for(int i=0;i<N;i++){
        int pos = rand()%10;
        cout << nombres[pos] << " " << apellidos[pos] << endl;
    }
}

int main(){
    srand(time(0));

    vector<string> nombres = {
        "Juan","Maria","Luis","Carmen","Pedro",
        "Rosa","Jose","Ana","Carlos","Elena"
    };

    vector<string> apellidos = {
        "Mamani","Quispe","Choque","Condori","Flores",
        "Vargas","Rojas","Torrez","Gonzales","Lopez"
    };

    int N;
    cout<<"Cantidad: ";
    cin>>N;

    generar(nombres, apellidos, N);

    return 0;
}