// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creación: 15/04/2026
// Número de ejercicio: 3

#include <iostream>
#include <vector>
#include <string>
using namespace std;

void limpiarBitacora(vector<string> &registros, char caracterProhibido, int &correcciones){
    correcciones = 0;

    for(int i=0;i<registros.size();i++){
        string nuevo = "";

        for(int j=0;j<registros[i].size();j++){
            if(registros[i][j] == caracterProhibido){
                correcciones++;
            } else {
                nuevo += registros[i][j];
            }
        }

        registros[i] = nuevo;
    }
}

int main(){
    vector<string> registros = {"marc#","ca#rla","Pe#dro"};
    int correcciones;

    cout<<"Antes:\n";
    for(auto x: registros) cout<<x<<endl;

    limpiarBitacora(registros, '#', correcciones);

    cout<<"Despues:\n";
    for(auto x: registros) cout<<x<<endl;

    cout<<"Correcciones: "<<correcciones<<endl;

    return 0;
}