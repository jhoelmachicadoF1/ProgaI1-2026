// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creación: 15/04/2026
// Número de ejercicio: 1

#include <iostream>
#include <vector>
#include <string>
using namespace std;

void procesarResultados(const vector<string> &nombres, vector<double> &notas, double &promedio, int &aprobados){
    double suma = 0;
    aprobados = 0;

    for(int i=0;i<notas.size();i++){
        if(notas[i]>=45 && notas[i]<=50){
            notas[i] = 51;
        }

        if(notas[i] >= 51){
            aprobados++;
        }

        suma += notas[i];
    }

    promedio = suma / notas.size();
}

int main(){
    vector<string> nombres = {"Ana","Luis","Pedro"};
    vector<double> notas = {40,48,90};

    double promedio;
    int aprobados;

    procesarResultados(nombres, notas, promedio, aprobados);

    cout<<"Lista actualizada:\n";
    for(int i=0;i<nombres.size();i++){
        cout<<nombres[i]<<" -> "<<notas[i]<<endl;
    }

    cout<<"Promedio: "<<promedio<<endl;
    cout<<"Aprobados: "<<aprobados<<endl;

    return 0;
}