// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creación: 15/04/2026
// Número de ejercicio: 2

#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
using namespace std;

void inicializarInventario(int bodega[3][3]){
    for(int i=0;i<3;i++){
        for(int j=0;j<3;j++){
            bodega[i][j] = rand()%101;
        }
    }
}

void balancearCarga(int bodega[3][3], int filaProducto, int &totalTransferido){
    if(bodega[filaProducto][0] > 80){
        int exceso = bodega[filaProducto][0] - 80;
        bodega[filaProducto][0] = 80;
        bodega[filaProducto][1] += exceso;
        totalTransferido += exceso;
    }
}

void mostrarReporte(const vector<string> &nombres, int bodega[3][3]){
    for(int i=0;i<3;i++){
        cout<<nombres[i]<<": ";
        for(int j=0;j<3;j++){
            cout<<bodega[i][j]<<" ";
        }
        cout<<endl;
    }
}

int main(){
    srand(time(0));

    int bodega[3][3];
    int totalTransferido = 0;

    vector<string> nombres = {"Prod1","Prod2","Prod3"};

    inicializarInventario(bodega);

    for(int i=0;i<3;i++){
        balancearCarga(bodega, i, totalTransferido);
    }

    mostrarReporte(nombres, bodega);

    cout<<"Total transferido: "<<totalTransferido<<endl;

    return 0;
}