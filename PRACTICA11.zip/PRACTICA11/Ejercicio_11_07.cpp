// Materia: Programación I, Paralelo 4
// Grupo: 3.
// Autor: Jhel Marco Machicado Flores.
// Fecha creación: 04/05/2026
// Número de ejercicio: 7

#include <iostream>
using namespace std;

int calcularQ(int n)
{
    if (n == 1)
    {
        return 1;
    }
    else
    {
        return (n * n) + calcularQ(n - 1);
    }
}

int main()
{
    int n;

    cout << "FUNCION Q(n) = 1^2 + 2^2 + 3^2 + ... + n^2" << endl;
    cout << "Ingrese el valor de n: ";
    cin >> n;

    if (n <= 0)
    {
        cout << "Debe ingresar un numero mayor a 0." << endl;
    }
    else
    {
        cout << "El resultado de Q(" << n << ") es: " << calcularQ(n) << endl;
    }

    return 0;
}
