// Materia: Programación I, Paralelo 4
// Grupo: 3.
// Autor: Jhel Marco Machicado Flores.
// Fecha creación: 04/05/2026
// Número de ejercicio: 4

#include <iostream>
using namespace std;

int mcd(int a, int b)
{
    if (b == 0)
    {
        return a;
    }
    else
    {
        return mcd(b, a % b);
    }
}

int main()
{
    int a, b;

    cout << "MAXIMO COMUN DIVISOR" << endl;
    cout << "Ingrese el primer numero: ";
    cin >> a;
    cout << "Ingrese el segundo numero: ";
    cin >> b;

    if (a < 0)
    {
        a = a * -1;
    }

    if (b < 0)
    {
        b = b * -1;
    }

    cout << "El MCD es: " << mcd(a, b) << endl;

    return 0;
}
