// Materia: Programación I, Paralelo 4
// Grupo: 3.
// Autor: Jhel Marco Machicado Flores.
// Fecha creación: 04/05/2026
// Número de ejercicio: 5

#include <iostream>
using namespace std;

int sumarVector(int vector[], int n)
{
    if (n == 0)
    {
        return 0;
    }
    else
    {
        return vector[n - 1] + sumarVector(vector, n - 1);
    }
}

void leerVector(int vector[], int n)
{
    for (int i = 0; i < n; i++)
    {
        cout << "Ingrese el elemento " << i + 1 << ": ";
        cin >> vector[i];
    }
}

int main()
{
    int n;
    int vector[100];

    cout << "SUMA RECURSIVA DE UN VECTOR" << endl;
    cout << "Ingrese la cantidad de elementos: ";
    cin >> n;

    if (n <= 0 || n > 100)
    {
        cout << "Cantidad no valida." << endl;
    }
    else
    {
        leerVector(vector, n);
        cout << "La suma de los elementos es: " << sumarVector(vector, n) << endl;
    }

    return 0;
}
