// Materia: Programación I, Paralelo 4
// Grupo: 3.
// Autor: Jhel Marco Machicado Flores.
// Fecha creación: 04/05/2026
// Número de ejercicio: 8

#include <iostream>
using namespace std;

void ullman(int n)
{
    cout << n << " ";

    if (n == 1)
    {
        return;
    }
    else
    {
        if (n % 2 == 0)
        {
            ullman(n / 2);
        }
        else
        {
            ullman((n * 3) + 1);
        }
    }
}

int main()
{
    int n;

    cout << "CONJETURA DE ULLMAN" << endl;
    cout << "Ingrese un numero entero mayor a 1: ";
    cin >> n;

    if (n <= 1)
    {
        cout << "Debe ingresar un numero mayor a 1." << endl;
    }
    else
    {
        cout << "Secuencia: ";
        ullman(n);
        cout << endl;
    }

    return 0;
}
