// Materia: Programación I, Paralelo 4
// Grupo: 3.
// Autor: Jhel Marco Machicado Flores.
// Fecha creación: 04/05/2026
// Número de ejercicio: 3

#include <iostream>
using namespace std;

int fibonacci(int n)
{
    if (n == 0)
    {
        return 0;
    }
    else
    {
        if (n == 1)
        {
            return 1;
        }
        else
        {
            return fibonacci(n - 1) + fibonacci(n - 2);
        }
    }
}

int main()
{
    int n;

    cout << "FIBONACCI" << endl;
    cout << "Ingrese la posicion n: ";
    cin >> n;

    if (n < 0)
    {
        cout << "Debe ingresar un numero positivo." << endl;
    }
    else
    {
        cout << "El numero Fibonacci en la posicion " << n << " es: " << fibonacci(n) << endl;
    }

    return 0;
}
