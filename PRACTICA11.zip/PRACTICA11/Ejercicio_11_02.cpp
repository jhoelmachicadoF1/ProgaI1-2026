// Materia: Programación I, Paralelo 4
// Grupo: 3.
// Autor: Jhel Marco Machicado Flores.
// Fecha creación: 04/05/2026
// Número de ejercicio: 2

#include <iostream>
using namespace std;

long long potencia(int base, int exponente)
{
    if (exponente == 0)
    {
        return 1;
    }
    else
    {
        return base * potencia(base, exponente - 1);
    }
}

int main()
{
    int base, exponente;

    cout << "POTENCIA DE UN NUMERO" << endl;
    cout << "Ingrese la base: ";
    cin >> base;
    cout << "Ingrese el exponente: ";
    cin >> exponente;

    if (exponente < 0)
    {
        cout << "Este programa solo trabaja con exponentes positivos." << endl;
    }
    else
    {
        cout << base << " elevado a " << exponente << " es: " << potencia(base, exponente) << endl;
    }

    return 0;
}
