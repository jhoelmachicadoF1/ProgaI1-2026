// Materia: Programación I, Paralelo 4
// Grupo: 3.
// Autor: Jhel Marco Machicado Flores.
// Fecha creación: 04/05/2026
// Número de ejercicio: 1

#include <iostream>
using namespace std;

int sumarDigitos(int numero)
{
    if (numero == 0)
    {
        return 0;
    }
    else
    {
        return (numero % 10) + sumarDigitos(numero / 10);
    }
}

int main()
{
    int numero;

    cout << "SUMA DE DIGITOS" << endl;
    cout << "Ingrese un numero entero positivo: ";
    cin >> numero;

    if (numero < 0)
    {
        cout << "Debe ingresar un numero positivo." << endl;
    }
    else
    {
        cout << "La suma de sus digitos es: " << sumarDigitos(numero) << endl;
    }

    return 0;
}
