// Materia: Programación I, Paralelo 4
// Grupo: 3.
// Autor: Jhel Marco Machicado Flores.
// Fecha creación: 04/05/2026
// Número de ejercicio: 6

#include <iostream>
using namespace std;

void leerVector(int vector[], int n, int numeroVector)
{
    for (int i = 0; i < n; i++)
    {
        cout << "Vector " << numeroVector << ", elemento " << i + 1 << ": ";
        cin >> vector[i];
    }
}

bool compararVectores(int vector1[], int vector2[], int n, int posicion)
{
    if (posicion == n)
    {
        return true;
    }
    else
    {
        if (vector1[posicion] != vector2[posicion])
        {
            return false;
        }
        else
        {
            return compararVectores(vector1, vector2, n, posicion + 1);
        }
    }
}

int main()
{
    int n;
    int vector1[100];
    int vector2[100];

    cout << "COMPARAR DOS VECTORES" << endl;
    cout << "Ingrese la cantidad de elementos: ";
    cin >> n;

    if (n <= 0 || n > 100)
    {
        cout << "Cantidad no valida." << endl;
    }
    else
    {
        cout << "Ingrese datos del primer vector" << endl;
        leerVector(vector1, n, 1);

        cout << "Ingrese datos del segundo vector" << endl;
        leerVector(vector2, n, 2);

        if (compararVectores(vector1, vector2, n, 0))
        {
            cout << "Los vectores son iguales." << endl;
        }
        else
        {
            cout << "Los vectores no son iguales." << endl;
        }
    }

    return 0;
}
