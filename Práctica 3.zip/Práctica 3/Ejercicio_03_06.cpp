// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Carnet: 7080018
// Carrera del estudiante: Ingeniería Biomédica 
// Fecha creación: 03/03/2026#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main() 
{
    srand(time(0));
    int n = 0; 
    int numero1 = 0; 
    int numero2 = 0; 
    int numero3 = 0;
    int panales = 0;

    cout << "Ingrese el total de ninos : ";
    cin >> n;
    numero1 = rand() % (n + 1);
    int sobra = n - numero1;
    if (sobra > 0) 
    {
        numero2 = rand() % (sobra + 1);
    } else 
    {
        numero2 = 0;
    }
    numero3 = n - numero1 - numero2;

    panales = (numero1 * 6) + (numero2 * 3) + (numero3 * 2);

    cout << "Ninos de 1 ano: " << numero1 << " (Consumen " << numero1 * 6 << ")";
    cout << "Ninos de 2 anos: " << numero2 << " (Consumen " << numero2 * 3 << ")";
    cout << "Ninos de 3 anos: " << numero3 << " (Consumen " << numero3 * 2 << ")";
    cout << "Total panales por dia: " << panales << " PANALES";

    return 0;
}