// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Carnet: 7080018
// Carrera del estudiante: Ingeniería Biomédica 
// Fecha creación: 03/03/2026
#include <iostream>
#include <cstdlib> 
#include <ctime>  

using namespace std;

int main() 
{
    srand(time(0));
    int n = 0;
    int dado= 0;
    int pares = 0;

    cout << "Cuantas veces se lanzará el dado ";
    cin >> n;

    for (int i = 1; i <= n; i++) 
    {
        dado = rand() % 6 + 1;
        if (dado % 2 == 0) 
        {   
            pares++;
        }
    }

    cout << "Frecuencia de caras pares: " << pares;
    return 0;
}