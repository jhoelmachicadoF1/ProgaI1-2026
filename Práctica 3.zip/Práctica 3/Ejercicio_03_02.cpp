// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Carnet: 7080018
// Carrera del estudiante: Ingeniería Biomédica 
// Fecha creación: 03/03/2026
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main() 
{
    srand(time(0));
    int n = 0;
    int resultado = 0;
    double cara = 0, cruz = 0;

    cout << "Cuantas veces se lanzará la moneda ";
    cin >> n;

    for (int i = 0; i < n; i++) 
    {
        resultado = rand() % 2;
        if (resultado == 0)
        {
            cara++;
        } else 
        {
            cruz++;
        }
    }

    cout << "Porcentaje de Caras: " << (cara / n) * 100 << "%";
    cout << "\n Porcentaje de Cruz: " << (cruz / n) * 100 << "%" ;

    return 0;
}