// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Carnet: 7080018
// Carrera del estudiante: Ingeniería Biomédica 
// Fecha creación: 03/03/2026
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main() 
{
    srand(time(0));
    int n = 0;
    int numero = 0; 
    int mayor = 0;
    int menor = 1001;
    int suma = 0;

    cout << "Cuantos numeros se generaran ";
    cin >> n;

    for (int i = 0; i < n; i++) 
    {
        numero = rand() % 1000 + 1;
        suma += numero;

        if (numero > mayor) mayor = numero;
        if (numero < menor) menor = numero;
    }

    cout << "Sumatoria: " << suma;
    cout << "\n Promedio: " << (double)suma / n;
    cout << "\n Mayor: " << mayor;
    cout << "\n Menor: " << menor;

    return 0;
}