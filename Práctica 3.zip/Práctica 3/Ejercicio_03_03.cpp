// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Carnet: 7080018
// Carrera del estudiante: Ingeniería Biomédica 
// Fecha creación: 03/03/2026
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main() 
{
    srand(time(0));
    int num = rand() % 10 + 1;
    long long factorial = 1;

    cout << "Numero generado: " << num;

    for (int i = 1; i <= num; i++) 
    {
        factorial = factorial * i;
    }

    cout << "Factorial es: " << factorial;
    return 0;
}