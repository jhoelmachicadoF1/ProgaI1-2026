// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Carnet: 7080018
// Carrera del estudiante: Ingeniería Biomédica 
// Fecha creación: 03/03/2026
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main() 
{
    srand(time(0));
    int n = 0;
    int numero = 0;
    int primos = 0;
    int divisores = 0;

    cout << "Cuantos numeros generara";
    cin >> n;

    for (int i = 0; i < n; i++) 
    {
        numero = rand() % 10000 + 1;
        cout << numero << " ";

        divisores = 0;
        for (int j = 1; j <= numero; j++) 
        {
            if (numero % j == 0) divisores++;
        }

        if (divisores == 2) 
        { 
            primos++;
        }
    }

    cout << "\nTotal de numeros primos: " << primos;
    return 0;
}