// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Carnet: 7080018
// Carrera: Ingeniería Biomédica
// Fecha creación: 04/03/2026

#include <iostream>
using namespace std;

int sumar (int n) 
{
    int suma = 0;
    for(int i = 1; i <= n; i++) 
    {
        suma += i;
    }
    return suma;
}

int main() 
{
    int limite = 0;
    cout << "Suma desde 1 hasta: ";
    cin >> limite;
    cout << "La suma total es: " << sumar(limite);
    return 0;
}