// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Carnet: 7080018
// Carrera: Ingeniería Biomédica
// Fecha creación: 04/03/2026

#include <iostream>
using namespace std;

double Notas(double numero1, double numero2) 
{
    return (numero1 + numero2) / 2;
}

int main() 
{
    double nota1 = 0;
    double nota2 = 0;
    cout << "Ingrese nota 1: ";
    cin >> nota1;
    cout << "Ingrese nota 2: ";
    cin >> nota2;
    cout << "El promedio es: " << Notas(nota1, nota2);
    return 0;
}