// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Carnet: 7080018
// Carrera: Ingeniería Biomédica
// Fecha creación: 04/03/2026

#include <iostream>
using namespace std;

bool Par(int n) 
{
    if (n % 2 == 0) return true;
    else return false;
}

int main() 
{
    int numero = 0;
    cout << "Ingrese un numero: ";
    cin >> numero;
    if (Par(numero)) cout << "Es par";
    else cout << "Es impar" ;
    return 0;
}