// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Carnet: 7080018
// Carrera: Ingeniería Biomédica
// Fecha creación: 04/03/2026

#include <iostream>
using namespace std;

double Area(double base, double altura) 
{
    return (base * altura) / 2;
}

int main() 
{
    double base = 0;
    double altura = 0;
    cout << "Ingrese la base: ";
    cin >> base;
    cout << "Ingrese la altura: ";
    cin >> altura;
    cout << "El area es: " << Area(base, altura);
    return 0;
}