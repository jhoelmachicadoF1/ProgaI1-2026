// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Carnet: 7080018
// Carrera: Ingeniería Biomédica
// Fecha creación: 04/03/2026

#include <iostream>
using namespace std;

int Digitos(int n) 
{
    int cuenta = 0;
    if (n == 0) return 1;
    while (n > 0) 
    {
        n = n / 10; 
        cuenta++;
    }
    return cuenta;
}

int main() 
{
    int numero = 0;
    cout << "Ingrese un numero: ";
    cin >> numero;
    cout << "Tiene " << Digitos(numero) << " digitos.";
    return 0;
}