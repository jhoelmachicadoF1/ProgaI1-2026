// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Carnet: 7080018
// Carrera: Ingeniería Biomédica
// Fecha creación: 04/03/2026

#include <iostream>
using namespace std;


int Mayor(int numero1, int numero2, int numero3) 
{
    int mayor = numero1;
    if (numero2 > mayor) mayor = numero2;
    if (numero3 > mayor) mayor = numero3;
    return mayor;
}

int main() {
    int a = 0;
    int b = 0;
    int c = 0;
    cout << "Ingrese tres numeros enteros: ";
    cin >> a >> b >> c;
    cout << "El numero mayor es: " << Mayor(a, b, c) << endl;
    return 0;
}