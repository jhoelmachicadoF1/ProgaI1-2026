// Materia: Programación I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Carnet: 7080018
// Carrera: Ingeniería Biomédica
// Fecha creación: 04/03/2026

#include <iostream>
using namespace std;

double Distancia(double velocidad, double tiempo) 
{
    return velocidad * tiempo;
}

int main() 
{
    double velocidad, tiempo;
    cout << "Ingrese velocidad (v): ";
    cin >> velocidad;
    cout << "Ingrese tiempo (t): ";
    cin >> tiempo;
    cout << "La distancia es: " << Distancia(velocidad, tiempo);
    return 0;
}