// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 13/04/2026
// Numero de ejercicio: 5

#include <iostream>
using namespace std;

void leerMatriz(int matriz[50][50], int filas, int columnas, string nombre) {
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
            cout << "Ingrese " << nombre << "[" << i << "][" << j << "]: ";
            cin >> matriz[i][j];
        }
    }
}

void multiplicarMatrices(int matriz1[50][50], int matriz2[50][50], int resultado[50][50], int n, int m) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            resultado[i][j] = 0;

            for (int k = 0; k < m; k++) {
                resultado[i][j] = resultado[i][j] + matriz1[i][k] * matriz2[k][j];
            }
        }
    }
}

void mostrarMatriz(int matriz[50][50], int filas, int columnas) {
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
            cout << matriz[i][j] << " ";
        }
        cout << endl;
    }
}

int main() {
    int matriz1[50][50];
    int matriz2[50][50];
    int resultado[50][50];
    int n, m;

    cout << "Ingrese N: ";
    cin >> n;

    cout << "Ingrese M: ";
    cin >> m;

    cout << "\nPrimera matriz de N x M" << endl;
    leerMatriz(matriz1, n, m, "matriz1");

    cout << "\nSegunda matriz de M x N" << endl;
    leerMatriz(matriz2, m, n, "matriz2");

    multiplicarMatrices(matriz1, matriz2, resultado, n, m);

    cout << "\nResultado de la multiplicacion:" << endl;
    mostrarMatriz(resultado, n, n);

    return 0;
}
