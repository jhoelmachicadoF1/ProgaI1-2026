// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 13/04/2026
// Numero de ejercicio: 6

#include <iostream>
using namespace std;

void leerMatriz(int matriz[50][50], int n, int m) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cout << "Ingrese el valor [" << i << "][" << j << "]: ";
            cin >> matriz[i][j];
        }
    }
}

void transponerMatriz(int matriz[50][50], int transpuesta[50][50], int n, int m) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            transpuesta[j][i] = matriz[i][j];
        }
    }
}

void mostrarMatriz(int matriz[50][50], int filas, int columnas) {
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
            cout << matriz[i][j] << " ";
        }
        cout << endl;
    }
}

int main() {
    int matriz[50][50];
    int transpuesta[50][50];
    int n, m;

    cout << "Ingrese cantidad de filas N: ";
    cin >> n;

    cout << "Ingrese cantidad de columnas M: ";
    cin >> m;

    leerMatriz(matriz, n, m);

    cout << "\nMatriz original:" << endl;
    mostrarMatriz(matriz, n, m);

    transponerMatriz(matriz, transpuesta, n, m);

    cout << "\nMatriz transpuesta:" << endl;
    mostrarMatriz(transpuesta, m, n);

    return 0;
}
