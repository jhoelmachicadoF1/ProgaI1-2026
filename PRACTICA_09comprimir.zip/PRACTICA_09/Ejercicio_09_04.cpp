// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 13/04/2026
// Numero de ejercicio: 4

#include <iostream>
using namespace std;

void generarMatriz(int matriz[50][50], int n) {
    int inicio = 1;

    for (int i = 0; i < n; i++) {
        int valor = inicio;

        for (int j = 0; j < n; j++) {
            matriz[i][j] = valor;
            valor++;
        }

        inicio = inicio + 2;
    }
}

void mostrarMatriz(int matriz[50][50], int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << matriz[i][j] << " ";
        }
        cout << endl;
    }
}

int main() {
    int matriz[50][50];
    int n;

    cout << "Ingrese el orden de la matriz: ";
    cin >> n;

    generarMatriz(matriz, n);

    cout << "\nMatriz generada:" << endl;
    mostrarMatriz(matriz, n);

    return 0;
}
