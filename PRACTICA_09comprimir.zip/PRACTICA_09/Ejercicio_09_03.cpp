// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 13/04/2026
// Numero de ejercicio: 3

#include <iostream>
#include <vector>
using namespace std;

const int FILAS = 3;
const int COLUMNAS = 4;

void mostrarMatriz(char matriz[FILAS][COLUMNAS]) {
    cout << "a) Mostrar matriz" << endl;

    for (int i = 0; i < FILAS; i++) {
        for (int j = 0; j < COLUMNAS; j++) {
            cout << matriz[i][j] << " ";
        }
        cout << endl;
    }
}

void filasColumnasLibres(char matriz[FILAS][COLUMNAS], int &filasLibres, int &columnasLibres) {
    filasLibres = 0;
    columnasLibres = 0;

    for (int i = 0; i < FILAS; i++) {
        bool libre = true;

        for (int j = 0; j < COLUMNAS; j++) {
            if (matriz[i][j] == 'x') {
                libre = false;
            }
        }

        if (libre == true) {
            filasLibres++;
        }
    }

    for (int j = 0; j < COLUMNAS; j++) {
        bool libre = true;

        for (int i = 0; i < FILAS; i++) {
            if (matriz[i][j] == 'x') {
                libre = false;
            }
        }

        if (libre == true) {
            columnasLibres++;
        }
    }
}

void posicionesMuertos(char matriz[FILAS][COLUMNAS], vector<int> &filas, vector<int> &columnas) {
    for (int i = 0; i < FILAS; i++) {
        for (int j = 0; j < COLUMNAS; j++) {
            if (matriz[i][j] == 'x') {
                filas.push_back(i);
                columnas.push_back(j);
            }
        }
    }
}

int cantidadMuertos(vector<int> filas) {
    return filas.size();
}

int main() {
    char matriz[FILAS][COLUMNAS] = {
        {'x', 'o', 'x', 'o'},
        {'o', 'o', 'o', 'o'},
        {'o', 'o', 'x', 'o'}
    };

    vector<int> filas;
    vector<int> columnas;
    int filasLibres;
    int columnasLibres;
    int muertosPrimeraColumna = 0;

    mostrarMatriz(matriz);

    filasColumnasLibres(matriz, filasLibres, columnasLibres);

    cout << "b) filas libres: " << filasLibres << endl;
    cout << "   columnas libres: " << columnasLibres << endl;

    posicionesMuertos(matriz, filas, columnas);

    cout << "c) Posiciones en la matriz:" << endl;
    for (int i = 0; i < filas.size(); i++) {
        cout << filas[i] << " -- " << columnas[i] << endl;
    }

    cout << "d) total muertos vivientes: " << cantidadMuertos(filas) << endl;

    for (int i = 0; i < columnas.size(); i++) {
        if (columnas[i] == 0) {
            muertosPrimeraColumna++;
        }
    }

    if (muertosPrimeraColumna >= 2) {
        cout << "e) no es posible entrar al complejo" << endl;
    } else {
        cout << "e) es posible entrar al complejo" << endl;
    }

    return 0;
}
