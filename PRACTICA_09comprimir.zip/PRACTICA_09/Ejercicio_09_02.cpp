// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 13/04/2026
// Numero de ejercicio: 2

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cmath>
using namespace std;

void generarMatriz(int matriz[50][50], int n, int a, int b) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            matriz[i][j] = a + rand() % (b - a + 1);
        }
    }
}

void mostrarMatriz(int matriz[50][50], int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << matriz[i][j] << " ";
        }
        cout << endl;
    }
}

int sumaUltimaColumna(int matriz[50][50], int n) {
    int suma = 0;

    for (int i = 0; i < n; i++) {
        suma = suma + matriz[i][n - 1];
    }

    return suma;
}

int productoUltimaFila(int matriz[50][50], int n) {
    int producto = 1;

    for (int j = 0; j < n; j++) {
        producto = producto * matriz[n - 1][j];
    }

    return producto;
}

void mayorValor(int matriz[50][50], int n, int &mayor, int &fila, int &columna) {
    mayor = matriz[0][0];
    fila = 0;
    columna = 0;

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (matriz[i][j] > mayor) {
                mayor = matriz[i][j];
                fila = i;
                columna = j;
            }
        }
    }
}

double desviacionEstandar(int matriz[50][50], int n) {
    double suma = 0;
    double promedio;
    double sumaCuadrados = 0;
    int cantidad = n * n;

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            suma = suma + matriz[i][j];
        }
    }

    promedio = suma / cantidad;

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            sumaCuadrados = sumaCuadrados + pow(matriz[i][j] - promedio, 2);
        }
    }

    return sqrt(sumaCuadrados / cantidad);
}

int main() {
    srand(time(0));

    int matriz[50][50];
    int n, a, b;
    int mayor, fila, columna;

    cout << "Ingrese el orden de la matriz: ";
    cin >> n;

    cout << "Ingrese el valor minimo A: ";
    cin >> a;

    cout << "Ingrese el valor maximo B: ";
    cin >> b;

    generarMatriz(matriz, n, a, b);

    cout << "\nMatriz generada:" << endl;
    mostrarMatriz(matriz, n);

    mayorValor(matriz, n, mayor, fila, columna);

    cout << "\nSuma de la ultima columna: " << sumaUltimaColumna(matriz, n) << endl;
    cout << "Producto de la ultima fila: " << productoUltimaFila(matriz, n) << endl;
    cout << "Mayor valor: " << mayor << endl;
    cout << "Posicion del mayor valor: fila " << fila << ", columna " << columna << endl;
    cout << "Desviacion estandar: " << desviacionEstandar(matriz, n) << endl;

    return 0;
}
