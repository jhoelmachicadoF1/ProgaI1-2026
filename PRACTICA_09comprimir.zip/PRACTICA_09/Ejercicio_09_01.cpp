// Materia: Programacion I, Paralelo 4
// Autor: Jhoel Marco Machicado Flores
// Fecha creacion: 13/04/2026
// Numero de ejercicio: 1

#include <iostream>
using namespace std;

void leerMatriz(int matriz[50][50], int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << "Ingrese el valor [" << i << "][" << j << "]: ";
            cin >> matriz[i][j];
        }
    }
}

void mostrarMatriz(int matriz[50][50], int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << matriz[i][j] << " ";
        }
        cout << endl;
    }
}

void cambiarFilas(int matriz[50][50], int n) {
    int auxiliar;

    for (int j = 0; j < n; j++) {
        auxiliar = matriz[0][j];
        matriz[0][j] = matriz[n - 1][j];
        matriz[n - 1][j] = auxiliar;
    }
}

int main() {
    int matriz[50][50];
    int n;

    cout << "Ingrese el orden de la matriz: ";
    cin >> n;

    leerMatriz(matriz, n);

    cout << "\nMatriz original:" << endl;
    mostrarMatriz(matriz, n);

    cambiarFilas(matriz, n);

    cout << "\nMatriz cambiando la primera fila con la ultima fila:" << endl;
    mostrarMatriz(matriz, n);

    return 0;
}
